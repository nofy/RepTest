<?php
require_once('config.php');
//require_once("banniere_param.php");
require_once(LINKTODB);
$bd = new BD();
$action = isset($_POST['action'])? $_POST['action']:null;
switch($action){
    //update level
    case 'update_level':
        $set_id = $_POST['set_id'];
        $level = $_POST['level'];
        
		/* Readmine 2274 - @Author:Nofy */
		$sqlLevel = "SELECT level,reference FROM `prod`.`bannieres_sets` WHERE set_id = '$set_id' LIMIT 1";		
		$resLevel = $bd->requete($sqlLevel);
		$ligLevel = mysql_fetch_assoc($resLevel);
		$ancien_Level = $ligLevel['level'];
		/* fin Readmine 2274 */

        $sql = "UPDATE `prod`.`bannieres_sets` SET `level`='$level' WHERE  set_id = '$set_id'";
        $r = $bd->requete($sql);
        if($r){

			/* Readmine 2274 - @Author:Nofy */
			
			//Quand on change le niveau d�un set soft => hard ou hard => soft 

			$SoftHard = false;

			if (($ancien_Level=='soft' && $level=='hard') || (($ancien_Level=='hard' && $level=='soft')))
			{
				// On envoie un mail
				$sujet = 'Banners Extranet Tool - a set level has been updated';
				$sujet   = 'Bannieres: Changement de niveau '.$level;
				
				$message  = 'Bonjour,<br /><br />';
				$message .= 'Changement de niveau d\'un set : '.$level.' <br />';
				$message .= 'Ancien niveau : '.$ancien_Level.'<br />';
				$message .= '(set_id='.$set_id.' : '.$ligLevel['reference'].')<br /><br />';
				$message .= 'Cordialement,<br />';
				$message .= 'L\'outil Bannières';

				$destinataire = EMAIL_LIST;
				
				$headers  = "From: \"Extranet\"<extranet@wister.biz>\n";
				$headers .= "Reply-To: extranet@wister.biz\n";								
				$headers .= "Content-Type: text/html; charset=\"utf-8\"";

				mail($destinataire, $sujet, $message, $headers);

				// Url des banni�res doit �tre modifi�				
				$sql = "SELECT * FROM `prod`.`bannieres` WHERE set_id='".$set_id."'";
				$resSql = $bd->requete($sql);
				
				while ($res = mysql_fetch_assoc($resSql))
				{
					$setValue=array();
					
					if ($res['type']=='image'):
						
						if ($level=='hard')
						$link_val = TARGET_LINK_HARD;			
						else
						$link_val = TARGET_LINK;
						
						$setValue[] = ' `liens` = CONCAT(\''.$link_val.'\', `nom`) ';

					endif;

					if (!empty($setValue)):
						$values = implode(',',$setValue);
						$up = "UPDATE `prod`.`bannieres` SET ";
						$up.= $values;
						$up.= " WHERE  banniere_id = '".$res['banniere_id']."'";
						$bd->requete($up);
					endif;
				}

				$SoftHard = true;

				$sql = "SELECT liens FROM `prod`.`bannieres` WHERE set_id='".$set_id."' AND etat='actif' AND type='image' ORDER BY banniere_id DESC LIMIT 1";
				$resSql = $bd->requete($sql);				
				$ligSql = mysql_fetch_assoc($resSql);
				$imageBan = $ligSql['liens'];
			}

			if ($SoftHard)
				echo $imageBan;
			else
				echo "TRUE";

			/* fin Readmine 2274 */
        }else{
            echo "FALSE";
        }
        break;
        
     //update univers
    case 'update_univers':
        $set_id = $_POST['set_id'];
        $univers = $_POST['univers'];
        
        $sql = "UPDATE `prod`.`bannieres_sets` SET `univers`='$univers' WHERE  set_id = '$set_id'";
        $r = $bd->requete($sql);
        if($r){
            echo "TRUE";
        }else{
            echo "FALSE";
        }
        break;
     
     //update niche
    case 'update_niche':
        $set_id = $_POST['set_id'];
        $niche = $_POST['niche'];//int
        
        $sql = "DELETE FROM `prod`.`bannieres_sets_listecontenus` WHERE set_id = '$set_id' ";
        $exec = $bd->requete($sql);
        
        $sql = "REPLACE INTO `prod`.`bannieres_sets_listecontenus` (set_id,id_listecontenus) VALUES (" . intval($set_id) . "," . intval($niche) . ") ;";
        $exec = $bd->requete($sql);
        
        if($exec){
            echo "TRUE";
        }else{
            echo "FALSE";
        }
        
        break;
        
    //test conexion ajax
    case 'check_conexion_ajax':
        $check_conexion_ajax = $_POST['check_conexion_ajax'];
        $resrc = $bd->requete($check_conexion_ajax);
        while ($row = mysql_fetch_assoc($resrc))
        {
            $result[] = $row;
        }
        echo json_encode($result);
        break;
        
    default :
        break;
        
    //update niche
    case 'update_langue':
        $set_id = $_POST['set_id'];
        $langue = $_POST['langue'];
        $tabLangue = explode('-', $langue);
        
        $sql = "UPDATE `prod`.`bannieres_sets` SET `langue_iso2`='".$tabLangue[0]."',`langue_iso3`='".$tabLangue[1]."',`langue_wister`='".$tabLangue[2]."' WHERE  set_id = '$set_id'";
        $r = $bd->requete($sql);
        if($r){
            echo "TRUE";
        }else{
            echo "FALSE";
        }
        
        break;
}
?>