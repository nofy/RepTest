<?php

require_once ("helper.php");

class set
{

    var $id = 0;
    var $ref = '';
    var $datedebut = '0000-00-00';
    var $datefin = '0000-00-00';
    var $etat = 'actif';
    var $type = '';
    var $level = '';
    var $univers = '';
    var $default = '0';
    var $langue = '';
    var $TSCamp = 0;
    var $TSPays = 0;
    var $TSLangue = 0;
    var $listCamp = array();
    var $listPays = array();
    var $listTheme = array();
    var $listeContenus=0;
//	var $listLangue	=array();

    var $niche = array();
    var $listBan = null;
    var $listBanTxt = null;

    /* Redmine 2494: MAJ de l'extranet de bannieres
     * Variable - Nombre banniere set par page par defaut (Pagination)
     */
    var $nb_banniere_set_per_page = 50;
    var $nb_total_bannieres_sets = 0;


    public function insertRef($bd)
    {
        if (empty($this->ref))
        {
            return false;
        }

        $sql = sprintf("SELECT * FROM `prod`.`bannieres_sets` WHERE reference='%s' ;", mysql_escape_string($this->ref));
        $res = $bd->requete($sql);
        $row = mysql_fetch_assoc($res);

        if (!empty($row))
            $this->getRef($bd, $this->ref);

        if (!empty($this->TSLangues)):
            $lg1 = "xx";
            $lg2 = "xxx";
            $lg3 = "XXX";
        else:
            $tab = explode('-', $this->langue);
            //$langs="'".$tab[0]."','".$tab[1]."','".$tab[2]."',";
            $lg1 = $tab[0];
            $lg2 = $tab[1];
            $lg3 = $tab[2];
        endif;
        $insert = sprintf("INSERT INTO `prod`.`bannieres_sets` (datedebut,datefin,etat,reference,langue_iso2,langue_iso3,langue_wister,`type`,level,univers,`default`)" .
                " VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');", mysql_escape_string($this->datedebut), mysql_escape_string($this->datefin), mysql_escape_string($this->etat), mysql_escape_string($this->ref), mysql_escape_string($lg1), mysql_escape_string($lg2), mysql_escape_string($lg3), mysql_escape_string($this->type), mysql_escape_string($this->level), mysql_escape_string($this->univers), mysql_escape_string($this->default)
        );



        $res = $bd->requete($insert);

        return true;
    }

    public function insert($bd)
    {
        if (!empty($this->id)){
            $req = "SELECT set_id FROM `prod`.`bannieres_sets` WHERE set_id ='" . $this->id . "' LIMIT 1;";
            $result = $bd->requete($req);
            $values = mysql_fetch_assoc($result);
        }else{
            $req = "SELECT set_id FROM `prod`.`bannieres_sets` WHERE reference ='" . $this->ref . "' LIMIT 1;";
            $result = $bd->requete($req);
            $values = mysql_fetch_assoc($result);
        }

        if (empty($values))
            return false;

        $this->id = $values['set_id'];
        if (!empty($this->TSPays)):

            $insert = "INSERT INTO `prod`.`bannieres_sets_pays` (set_id,code_pays) " .
                    " VALUES ('" . $values['set_id'] . "','TSS');";
            $result = $bd->requete($insert);

        elseif (!empty($this->listPays)):
            $arPays = array();

            foreach ($this->listPays as $lp):
                $arPays[] = "('" . $values['set_id'] . "','" . $lp . "')";
            endforeach;

            $strP = implode(',', $arPays);

            $insertP = "INSERT INTO `prod`.`bannieres_sets_pays` (set_id,code_pays) VALUES " . $strP . " ;";
            $bd->requete($insertP);

        endif;

        if (!empty($this->listCamp)):
            $arCamp = array();

            foreach ($this->listCamp as $lc):
                $arCamp[] = "('" . $values['set_id'] . "','" . $lc . "')";
            endforeach;

            $strC = implode(',', $arCamp);

            $insertP = "INSERT INTO `prod`.`bannieres_sets_campagnes` (set_id,campagne_id) VALUES " . $strC . " ;";
            $bd->requete($insertP);

        endif;

        if (!empty($this->niche)):
            $insertN = "INSERT INTO `prod`.`bannieres_sets_listecontenus` (set_id,id_listecontenus) VALUES (" . intval($values['set_id']) . "," . intval($this->niche[0]) . ") ;";
            $bd->requete($insertN);
        endif;

        return true;
    }

    public function update($bd)
    {

        if (!empty($this->id))
        {
            $sql1 = "UPDATE `prod`.`bannieres_sets` SET `datedebut` ='" . $this->datedebut . "' ," .
                    " `datefin`='" . $this->datefin . "' , `etat`='" . $this->etat . "', `reference`='" . $this->ref . "'," .
                    "`type`='" . $this->type . "',`level`='" . $this->level . "',`univers`='" . $this->univers . "',`default`=" . $this->default . ",";

            if (!empty($this->TSLangues)):
                $sql1.="`langue_iso2`='xx',`langue_iso3`='xxx',`langue_wister`='XXX'";
            else:
                $tab = explode('-', $this->langue);
                $sql1.="`langue_iso2`='" . $tab[0] . "',`langue_iso3`='" . $tab[1] . "',`langue_wister`='" . $tab[2] . "'";
            endif;

            $sql1.=" WHERE  set_id = '" . $this->id . "'";
            $bd->requete($sql1);

            $sql2 = "DELETE FROM `prod`.`bannieres_sets_pays` WHERE set_id = '" . $this->id . "'";
            $bd->requete($sql2);

            $sql4 = "DELETE FROM `prod`.`bannieres_sets_campagnes` WHERE set_id = '" . $this->id . "'";
            $bd->requete($sql4);

            $sql5 = "DELETE FROM `prod`.`bannieres_sets_listecontenus` WHERE set_id = '" . $this->id . "'";
            $bd->requete($sql5);

            return true;
        }
    }

    public function getRef($bd, $name = 'SET_')
    {
        $sql = "SELECT COUNT(set_id)as nb FROM `prod`.`bannieres_sets` WHERE reference LIKE '" . $name . "'%";
        $res = $bd->requete($sql);
        $nb = mysql_fetch_assoc($res);
        $nb['nb']++;
        $this->ref = $name . $nb['nb'];
    }

    /* Function to get Number of banniere set
     * @Author Nofy - Redmine 2494: MAJ de l'extranet de banni�res
     * @param $BD
     * @return numbre
     */
    public function getFieldAllSets($field, $bd=null) {
        $res = false;
        $result = false;
        $_tabField = array();

        switch ($field) {
            case 'type':
                $sql = " SELECT DISTINCT(`type`) FROM `bannieres_sets` ORDER BY type ASC ";
                $res = $bd->requete($sql);
                break;

            case 'univers': 
                $_tabField = array("hetero", "gay", "mixte");
                break;

            case 'niveau': 
                $_tabField = array("generaliste", "soft", "hard");
                break;

            case 'nom':
                $sql = " SELECT `set_id`,`reference` FROM `bannieres_sets` ORDER BY reference ASC ";
                $res = $bd->requete($sql);
                $this->nb_total_bannieres_sets = mysql_num_rows($res);
                break;

            case 'langue':
                $_tabField = $this->getAllLangue($bd);
                break;

            case 'niche':
                $_tabField = $this->getAllNiche($bd);
                break;

           default :
                return false;
                break;
        }

        if ($bd != null && $res) {
            if (mysql_num_rows($res) != 0){
                while ($list = mysql_fetch_object($res)) {
                    $all_list[] = $list;
                }
            }
            $result = $all_list;

        } else {
            $result = $_tabField;
        }

        return $result;
    }

    /**
     * Calcul de la limite sql par rapport du page en cours et au nombres d'�l�ments � afficher
     * @params: nb_resultats, nb_par_page, page_en_cours
     * return array(): Nbre de la page et limit sql
     */
    public function getParamsPagination() {
        $page_en_cours = isset($_GET['p']) ? $_GET["p"] : 1;
        $nb_par_page   = isset($_GET['nb']) ? $_GET['nb'] : $this->nb_banniere_set_per_page;
        $nb_resultats  = $this->nb_total_bannieres_sets;

        $max_page = ceil($nb_resultats / $nb_par_page);

        if (isset($page_en_cours) && $page_en_cours > 1) {
            if($page_en_cours > $max_page){
                $page_en_cours = $max_page;
            }
            $limit = ($page_en_cours * $nb_par_page) - $nb_par_page;
        } else {
           $page_en_cours = 1;
           $limit = 0;
        }

        return array($limit, $nb_par_page ,$max_page, $page_en_cours);
    }

    /** function to get critere recherche Set
     *  @return array ($critere , $jointure)
     */
    protected function getWhereSearchSet($post) {
        $critere = "";
        $jointure = "";
        if (!empty($post['nom_select'])){
            $critere = " WHERE BS.set_id = '" . trim($post['nom_select']) . "' ";
        } else {
            $critere = " WHERE 1=1 ";
            if (!empty($post['type_select'])){
                $critere .= " AND BS.type = '" . trim($post['type_select']) . "' ";
            }
            if (!empty($post['langue_select'])){
                $critere .= " AND BS.langue_iso2 = '" . trim($post['langue_select']) . "' ";
            }
            if (!empty($post['niveau_select'])){
                $critere .= " AND BS.level = '" . trim($post['niveau_select']) . "' ";
            }
            if (!empty($post['niche_select'])){
                $jointure.= " LEFT JOIN bannieres_sets_listecontenus AS BSL ON BS.set_id = BSL.set_id ";
                $jointure.= " LEFT JOIN aff_listecontenus AS AL ON  BSL.id_listecontenus = AL.id_listecontenus ";
                $critere .= " AND AL.id_listecontenus = '" . trim($post['niche_select']) . "' ";
            }
            if (!empty($post['univers_select'])){
                $critere .= " AND BS.univers = '" . trim($post['univers_select']) . "' ";
            }
        }

        return array($critere, $jointure);
    }

    /** function to get select langue in the search set
     *  @return nom
     */
    public function getLangueSelectSearch($bd,$curent_langue_iso2){
        $all_langue = $this->getAllLangue($bd);
        foreach($all_langue as $liste){
            if ($curent_langue_iso2 == $liste['langue_iso2']) {
                return $liste['nom'];
            }
        }
        return;
    }
    /** function to get select langue in the search set
     *  @return nom_listecontenusFRE
     */
    public function getNicheSelectSearch($bd,$curent_id_listecontenus){
        $all_niche = $this->getAllNiche($bd);
        foreach($all_niche as $liste){
            if ($curent_id_listecontenus == $liste['id_listecontenus']) {
                return $liste['nom_listecontenusFRE'] . " (" .getNomNicheRepli($all_niche,$liste['code_liste_repli']) . ")";
            }
        }
        return;
    }

    public function listSet($bd)
    {
        $sqlLC = "SELECT BSL.`set_id`,AL.nom_listecontenusFRE, AL.id_listecontenus" .
                " FROM `bannieres_sets_listecontenus` AS BSL, aff_listecontenus AS AL".
                " WHERE BSL.id_listecontenus=AL.id_listecontenus";
            
        $resLC = $bd->requete($sqlLC);
        $arraySet=array();
        while ($set = mysql_fetch_assoc($resLC))
        {
            if (!empty($arraySet[$set['set_id']])){
                $arraySet[$set['set_id']].=','.$set['nom_listecontenusFRE'];
                $nicheIds[$set['set_id']].=','.$set['id_listecontenus'];
            }
            else {
                $arraySet[$set['set_id']]=$set['nom_listecontenusFRE'];
                $nicheIds[$set['set_id']]=$set['id_listecontenus'];
            }
        }

        /* Criteres de recherche sur les sets */
        $where_search_sets = "";
        $joint_search_sets = "";
        $limit_pagination  = "";

        if (isset($_REQUEST['type']) && $_REQUEST['type'] == "search") 
        {
            list($where_search_sets, $joint_search_sets) = $this->getWhereSearchSet($_POST);
        } 
        else
        {
            // Pagination
            $this->getFieldAllSets("nom", $bd);
            list($debut, $nb_par_page ,$max_page, $page_en_cours) = $this->getParamsPagination();
            $limit_pagination  = " LIMIT " . $debut . ", " . $nb_par_page;
        }

        $sql =  " SELECT BS.set_id,BS.reference, BS.type, BS.univers, BS.default, BS.level, BS.etat, BS.langue_iso2 " .
                " FROM bannieres_sets AS BS " .
                  $joint_search_sets .
                  $where_search_sets .
                " ORDER BY etat DESC,type ASC, univers ASC, level ASC,reference ASC " .
                  $limit_pagination;

        $res = $bd->requete($sql);

        $result = '<h5>Les sets par d&eacute;fauts sont surlign&eacute;s en orange </h5>';
        if (!empty($where_search_sets))
        $result .= '<div class="label_nb_resultat">Nombre de r&eacute;sultat: ' . mysql_num_rows($res) . '</div>';

        $result.='<div id="listSet">';
        $result.='<table id="table_set" class="tablesorter" width="550">';
        $result.='<thead><tr>'.
                    '<th width:20%>Type&nbsp;&nbsp;&nbsp;&nbsp;</th>'.
                    '<th width:20%>Univers</th>'.
                    '<th width:20%>Niveau</th>'.
                    '<th width:40%>Nom</th>'.
                    '<th width:40%>Langue</th>'.
                    '<th width:5%>Niche</th>'.
                    '<th width:5%>Thumb</th>'.
                    '<th width:5%>Campagne</th>'.
                    '<th style="width:100px">Nbre Banni&egrave;res</th>'.
                '</tr></thead>';
        
        $refBanSet = array();
        while ($ban = mysql_fetch_assoc($res))
        {
            $firstThumbBanSetImg = "";
            if(!in_array($ban['reference'], $refBanSet)){
                
                $firstThumbBanSet    = $this->getThumbBanSet($bd,$ban['set_id']);
                if($firstThumbBanSet != null){
                    $firstThumbBanSetImg ="<img width='120' style='max-height:100px'  title='' alt='' src='$firstThumbBanSet->liens'>";
                }else{
                    $firstThumbBanSetImg = "";
                }
            }
            
            $link = 'accueil.php?cur=banniere&page=1&set=' . $ban['set_id'];
            $niche_id = isset($nicheIds[$ban['set_id']])?$nicheIds[$ban['set_id']]:0;
            if ($ban['etat'] == 'inactif')
                $result.='<tr desc="'.$niche_id.'" class="inactif" style="background-color:red;color:#FFF">';
            else if ($ban['default'] == 1)
                $result.='<tr desc="'.$niche_id.'" style="background-color:#F2A348">';
            else
                $result.='<tr desc="'.$niche_id.'" >';
            
            //modification directe level
            $option_generaliste = $ban['level'] == "generaliste" ? '<option value="generaliste" selected = "selected" >generaliste</option>':'<option value="generaliste"  >generaliste</option>';
            $option_soft = $ban['level'] == "soft" ? '<option value="soft" selected = "selected" >soft</option>':'<option value="soft"  >soft</option>';
            $option_hard = $ban['level'] == "hard" ? '<option value="hard" selected = "selected" >hard</option>':'<option value="hard"  >hard</option>';
            
            $select_level = '<select desc="'.$ban['set_id'].'" class="set_level" name="set_level">
                           '.$option_generaliste.'
                            '.$option_soft.'
                            '.$option_hard.'
                    </select>';
            
            //modification direct univers
            $option_hetero = $ban['univers'] == "hetero" ? '<option value="hetero" selected = "selected" >hetero</option>':'<option value="hetero"  >hetero</option>';
            $option_gay = $ban['univers'] == "gay" ? '<option value="gay" selected = "selected" >gay</option>':'<option value="gay"  >gay</option>';
            $option_mixte = $ban['univers'] == "mixte" ? '<option value="mixte" selected = "selected" >mixte</option>':'<option value="mixte"  >mixte</option>';

            $select_univers = '<select desc="'.$ban['set_id'].'" class="set_univers" name="set_univers">
                                    '.$option_hetero.'
                                            '.$option_gay.'
                                            '.$option_mixte.'
                            </select>';
            
            $result.='<td>' . $ban['type'] . '</td>' .
                    '<td align="center"><p style="display:none">' . $ban['univers'].'</p>' .$select_univers. '</td>' .
                    '<td align="center"><p style="display:none">' . $ban['level'] .'</p>' . $select_level.'</td>' .
                    '<td><a href="' . $link . '">' . $ban['reference'] . '</a></td>' ;
            $result.='<td>'.$this->getInputSelectLangue($bd,$ban['langue_iso2'],$ban['set_id']).'</td>';
            if (empty($arraySet[$ban['set_id']]))
                $result.='<td>&nbsp;</td>';
            else
                $result.='<td><!--<img src="'.URL_BASE.'modules/onglets/banniere/images/ban.png" alt="'.$arraySet[$ban['set_id']].'" title="'.$arraySet[$ban['set_id']].'"/><br />-->'.$this->getInputSelectNiche($bd,$arraySet[$ban['set_id']],$ban['set_id']).'</td>';
            
			/** Readmine 2274: Evolution Outil Banni�res de l'extranet
			 *	@Author: Nofy 
			 */
				$result .= '<td id="imgBan_'.$ban['set_id'].'" style="width:120px;max-height:100px">'.$firstThumbBanSetImg.'</td>';
			/* fin Readmine 2274 */
            
            //campagne
            $campagne = $this->getCampagneSet($bd,$ban['set_id']);
            $result .= "<td>$campagne</td>";
            $nb_banners = $this->getNbBannersBySize($bd,$ban['set_id']);
            $result .= "<td  style='width:100px;'><div style='width:100px;'>";
            foreach ($nb_banners as $banner_size) {
            	$result .= $banner_size->size." [".$banner_size->nb."]<br />";
            }
            
            $result .= 	"</div></td>";
            
            $result.='</tr>';
        }

        $result.='</table>';
        $result.='</div>';

        /* Pagination: Redmine 2494: MAJ de l'extranet de banni�res
         * @Author Nofy
         */
        if (empty($where_search_sets)) {
            $helper = new Helper();
            $result.= '<div class="bloc_pagination">';
            $result.= $helper->paginate('?cur=banniere&nb=' . $nb_par_page, '&p=', $max_page, $page_en_cours);
            $result.= $helper->paginateSelect($nb_par_page, $this->nb_total_bannieres_sets);
            $result.= '</div>';
        } else {
            $result.= '<div class="bloc_bouton_retour">';
            $result.= '<input type="button" name="retour" onClick="location.href=\'accueil.php?cur=banniere\'" value="Retour &agrave; la liste des sets" />';
            $result.= '</div>';
        }

        return $result;
    }

    public function init($bd, $id)
    {
        $sql = sprintf("SELECT * FROM `bannieres_sets` WHERE set_id=%s ;", mysql_escape_string($id));
        $res = $bd->requete($sql);
        $set = mysql_fetch_assoc($res);
        if (!empty($set)):
            $this->id = $set['set_id'];
            $this->datedebut = $set['datedebut'];
            $this->datefin = $set['datefin'];
            if ($set['langue_iso2'] == 'xx')
                $this->TSLangue = 1;
            else
                $this->langue = $set['langue_iso2'];

            if (substr($set['datefin'], 0, 10) == '0000-00-00')
            {
                $this->nodatelimit = 1;
            }

            $this->ref = $set['reference'];

            $this->etat = $set['etat'];
            $this->type = $set['type'];
            $this->level = $set['level'];
            $this->univers = $set['univers'];
            $this->default = $set['default'];

            $sqlP = "SELECT * FROM `bannieres_sets_pays` WHERE set_id=" . $id;
            $resP = $bd->requete($sqlP);
            while ($P = mysql_fetch_assoc($resP)):
                if ($P['code_pays'] == 'TSS')
                    $this->TSPays = 1;
                $this->listPays[] = $P['code_pays'];
            endwhile;

            $sqlC = "SELECT * FROM `bannieres_sets_campagnes` WHERE set_id=" . $id;
            $resC = $bd->requete($sqlC);
            while ($C = mysql_fetch_assoc($resC)):
                $this->listCamp[] = $C['campagne_id'];
            endwhile;

            $sqlBI = "SELECT * FROM `bannieres` WHERE  type='image' AND set_id=" . $id . " ORDER BY width DESC,height DESC";
            $this->listBan = $bd->requete($sqlBI);

            $sqlBT = "SELECT * FROM `bannieres` WHERE  type='text' AND set_id=" . $id;
            $this->listBanTxt = $bd->requete($sqlBT);

            $sqlN = "SELECT `id_listecontenus` FROM `bannieres_sets_listecontenus` WHERE set_id=" . $id;
            $resN = $bd->requete($sqlN);
            while ($N = mysql_fetch_assoc($resN)):
                $this->niche[] = $N['id_listecontenus'];
            endwhile;

        else:
            return false;
        endif;
    }



    //evolution 2274
    public function getThumbBanSet($bd,$set_id){
         $sqlBI = "SELECT * FROM `bannieres` 
                    WHERE   set_id=" . $set_id . " AND type='image' 
                    ORDER BY width DESC,height DESC
                    LIMIT 1";
         $rs = $bd->requete($sqlBI);
         while($row = mysql_fetch_object($rs)){
             $thumb[] = $row;
             return $thumb[0];
         }
         return null;
    }
    
    public function getNbBannersBySize($bd,$set_id){
    	$size_banner = array();
    	$sqlBI = "SELECT COUNT(banniere_id) AS nb, size FROM `bannieres`
                    WHERE   set_id=" . $set_id . " GROUP BY size";
    	$rs = $bd->requete($sqlBI);
    	while($row = mysql_fetch_object($rs)){
    		$size_banner[] = $row;
    	}
    	
    	return $size_banner;
    }    
    
    var $allNiche = null;
    protected function getAllNiche($bd){
        
        if($this->allNiche != null){
            return $this->allNiche;
        }

        $sql="SELECT L.*".
            " FROM aff_listecontenus L".
            " WHERE (L.restriction_distributeur IS NULL OR L.restriction_distributeur LIKE '')".
            " AND deprecated!=1".
            " ORDER BY nom_listecontenusFRE ASC, age DESC";
        $res = $bd->requete($sql);
        
        $all_niche = array();
        while ($liste = mysql_fetch_assoc($res))
        {
           $all_niche[] = $liste;
        }

       $this->allNiche = $all_niche;
       
       return $this->allNiche;
    }
    
    protected function getInputSelectNiche($bd,$curent_niche,$set_id){
        $all_niche = $this->getAllNiche($bd);
        $options = "<option></option>";
        $i=0;
        foreach($all_niche as $liste){
            $selected = $curent_niche == $liste['nom_listecontenusFRE'] ? "selected='selected'":"";
            $nomNicheRepli = $this->getNomNicheRepli($all_niche, $liste['code_liste_repli']);
            $options .= "<option value = '".$liste['id_listecontenus']."' $selected >". $liste['nom_listecontenusFRE']." ($nomNicheRepli)</option>";
            $i++;
        }
        
        if($i == 0){
            return "";
        }
        
        $inputSelectNiche = "<p style='display:none'>$curent_niche</p><select name='set_niche' class='set_niche' desc='$set_id'>$options</select>";
        
        return $inputSelectNiche;
    }
    
    protected function getNomNicheRepli($all_niche,$code_repli){
        foreach($all_niche as $liste){
            if($liste['code_listecontenus'] == $code_repli){
                return $liste['nom_listecontenusFRE'];
            }
        }
        return "...";
    }


    //get all langue
    var $allLangue = null;
    protected function getAllLangue($bd) {
        
        if($this->allLangue != null){
            return $this->allLangue;
        }
        
        $sql = "SELECT langue_iso2,langue_iso3,langue_wister,nom FROM `prod`.`bannieres_langue` ORDER BY nom ASC";

        $res = $bd->requete($sql);
        $all_langue = array();
        while ($liste = mysql_fetch_assoc($res)) {
            $all_langue[] = $liste;
        }

        $this->allLangue = $all_langue;

        return $this->allLangue;
    }
    
    protected function getInputSelectLangue($bd,$curent_langue_iso2,$set_id){ 
        $all_langue = $this->getAllLangue($bd);
        $options = $curent_langue_iso2 == 'xx'
                    ?   "<option value='xx-xxx-XXX' selected='selected'>Toutes les langues</option>"
                    :   "<option value='xx-xxx-XXX'>Toutes les langues</option>";
        $nom_langue_selected = "ZToutes les langues";
        $langue_name_value = "xx-xxx-XXX=$nom_langue_selected";
        $i=0;
        foreach($all_langue as $liste){
            $selected = $curent_langue_iso2 == $liste['langue_iso2'] ? "selected='selected'":"";
            $val = $liste['langue_iso2']."-".$liste['langue_iso3']."-".$liste['langue_wister'];
            $nom = $liste['nom'];
            $options .= "<option value = '$val' $selected >".$nom."</option>";
            if($curent_langue_iso2 == $liste['langue_iso2']){
                $nom_langue_selected = $liste['nom'];
            }
            $langue_name_value .= ";$val=$nom";
            $i++;
        }
        
        if($i == 0){
            return "";
        }
        
        $inputSelectLangue = "<p style='display:none'>$nom_langue_selected</p><select name='set_langue' class='set_langue' desc='$set_id' alt='".$langue_name_value."'>$options</select>";
        
        return $inputSelectLangue;
    }
    
    public function getCampagneSet($bd,$set_id){
        $sqlC = "SELECT * FROM `bannieres_sets_campagnes` WHERE set_id=" . $set_id;
        $sqlC = "SELECT ac.name,bsc.campagne_id FROM `aff_campagne` ac 
        INNER JOIN `bannieres_sets_campagnes` bsc
        ON ac.id = bsc.campagne_id AND bsc.set_id = $set_id";
        
            $resC = $bd->requete($sqlC);
            $campagneSet = "";
            while ($C = mysql_fetch_assoc($resC)):
                $campagneSet .= $C['name']."(".$C['campagne_id'].")<br/>";
            endwhile;
            return $campagneSet;
    }
    
}

?>
