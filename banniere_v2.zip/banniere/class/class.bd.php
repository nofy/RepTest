<?php
 class BD {
	public $hote;
	public $utilisateur;
	public $mdp;
	public $bd;
	public $lien;

	//Fonction d'ouverture de connexion à la BD
	function BD()
	{
    global $environnement,$utilisateur,$mdp,$hote;
  	$this->bd=$environnement;
  	$this->hote=$hote;
  	$this->utilisateur=$utilisateur;
  	$this->mdp=$mdp;
  	$this->lien=mysql_connect($this->hote, $this->utilisateur, $this->mdp, true);
  	mysql_select_db($this->bd);
  	register_shutdown_function(array(&$this, 'close'));
	}

	// Fonction d'execution de la requète à la BD
	function requete($uneRequete) {
		if (!$resultat=mysql_query($uneRequete, $this->lien)) {
			$errno=mysql_errno($this->lien);
			$error=mysql_error($this->lien);
			$ficHandle=fopen('bdLogs.txt', 'a+');
			$PrintError = date("Y-m-d H:i:s").' : '.$uneRequete.', error number : '.$errno.', error : '.$error;
			fwrite($ficHandle, $PrintError."\n");
			fclose($ficHandle);
			print $PrintError;
			exit;
		}
		return($resultat);
	}

	// Fonction de fermeture de connexion ?a BD
	function close(){
		@mysql_close($this->lien);
	}
}


?>