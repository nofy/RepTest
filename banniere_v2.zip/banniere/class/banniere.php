<?php
class banniere{
	var $ban_id=0;
	var $set_id =0;
	var $nom 	='';
	var $etat	='actif';
	var $type	='image';
	var $size	='';
	var $text	='';
	var $liens	='';
	var $format	='';
	var $width 	=0;
	var $height	=0;
	var $error=array();
	
	public function saveImg($bd,$set_id,$number=0,$level='hard'){
	
		$tabExt = array('jpg','gif','png','jpeg'); // Extensions autorisees
	
		$this->set_id=$set_id;
	
		$pathinfo = pathinfo($_FILES['ban']['name'][$number]);		// Recuperation de l'extension du fichier
                if (!empty($_POST['ban_actif'][0]) && $_POST['ban_actif'][0]=='actif')
                    $this->etat='actif';
		else
		    $this->etat='inactif';
		if(in_array(strtolower($pathinfo['extension']),$tabExt))							// On verifie l'extension du fichier
		{
		    $extension=strtolower($pathinfo['extension']);
		    $this->format=$extension;

			$infosImg = getimagesize($_FILES['ban']['tmp_name'][$number]);				// On recupere les dimensions du fichier
			if($infosImg[2] >= 1 && $infosImg[2] <= 14)
			{
							// On verifie les dimensions et taille de l'image
				if(($infosImg[0] >= 5) && ($infosImg[1] >= 5) && (filesize($_FILES['ban']['tmp_name'][$number]) <= MAX_SIZE))
				{
				    $this->width=$infosImg[0];
				    $this->height=$infosImg[1];
				    $this->size=$infosImg[0].'x'.$infosImg[1];
				    
					// Parcours du tableau d'erreurs
					if(isset($_FILES['ban']['error'][$number])&& UPLOAD_ERR_OK === $_FILES['ban']['error'][$number])
					{
						$this->nom = $this->set_id.'_'.str_replace('/','',$this->size).'_'.md5(uniqid()) .'.'. $extension;             // On renomme le fichier
				    
						if(!move_uploaded_file($_FILES['ban']['tmp_name'][$number], TARGET_BAN.$this->nom)){
							$this->error[] = 'Problème lors de l\'upload !';
						}else
						{
						    if ($level=='hard')
							$link_banniere=TARGET_LINK_HARD.$this->nom;
						    else
							$link_banniere=TARGET_LINK.$this->nom;
						    
						    $this->liens=$link_banniere;

						    $this->insert($bd);
						    return 'coooooll';
						}
					}
					else
						$this->error[]  = 'Une erreur interne a empêché l\'uplaod de l\'image';
				}
				else
					$this->error[]  = 'Erreur dans les dimensions de l\'image !';		//erreur sur les dimensions et taille de l'image
			}
			else
				$this->error[]  = 'Le fichier à uploader n\'est pas une image !';      //erreur sur le type de l'image
		}
		else
			$this->error[]  = 'L\'extension du fichier est incorrecte !';              //on affiche une erreur pour l'extension

		return var_dump($this->error);
	}
	
	public function saveTxt($bd,$set_id,$txt,$actif){
		$tabactif=array("actif","inactif");
		$this->set_id=$set_id;
		$this->type="text";
		if (!empty($txt)){
			if(get_magic_quotes_gpc()) // prevents duplicate backslashes
				$txt= stripslashes($txt);

			$txt = mysql_escape_string(htmlentities($txt, ENT_QUOTES));

			$txt=strip_tags($txt);
			if (!empty($txt)):
				$this->text=$txt;
				
				if (!empty($actif) && in_array($actif,$tabactif) && $actif=='actif')
                    $this->etat="actif";
				else
				    $this->etat="inactif";

				$this->insert($bd);
			endif;
		}
	}

	public function insert($bd)
	{
        $insertB='INSERT INTO `prod`.`bannieres` (set_id,nom,width,height,size,format,etat,type,liens,text) VALUES'.
				 '(\''.$this->set_id.'\',\''.$this->nom.'\',\''.$this->width.'\',\''.$this->height.'\',\''.$this->size.'\',\''.$this->format.'\','.
				 '\''.$this->etat.'\',\''.$this->type.'\',\''.$this->liens.'\',\''.$this->text.'\')';
        $bd->requete($insertB);
	}
	public function getBanImg($BI)
	{
		$this->type='image';
		$this->width=$BI['width'];
		$this->height=$BI['height'];
		$this->liens=$BI['liens'];
		//$this->text=$BI['text'];
		$this->etat=$BI['etat'];
		$this->set_id=$BI['set_id'];
		$this->ban_id=$BI['banniere_id'];
		$this->size=$BI['size'];
	}
	public function getBanTxt($BT)
	{
        $this->type='text';
		$this->text=$BT['text'];
		$this->etat=$BT['etat'];
		$this->set_id=$BT['set_id'];
		$this->ban_id=$BT['banniere_id'];
	}

	public function supprBanImg($bd,$id)
	{
	    if (!empty($id)):
		    $id=intval($id);
			$sqlBan="SELECT nom FROM `prod`.`bannieres` WHERE banniere_id='".$id."'";
			$res=$bd->requete($sqlBan);
		    $ban=mysql_fetch_assoc($res);
		    
		    unlink(TARGET_BAN.$ban['nom']);
		    
		    $sqlBan2="DELETE FROM `prod`.`bannieres` WHERE banniere_id = '".$id."'";
			$bd->requete($sqlBan2);
		    
		endif;
	}
	public function supprBanTxt($bd,$id)
	{
	    if (!empty($id)):
        	$id=intval($id);
			$sqlBan="DELETE FROM `prod`.`bannieres` WHERE banniere_id = '".$id."'";
			$bd->requete($sqlBan);
		endif;
	}
	
	public function MAJBan($bd,$id,$level='hard'){
	    $arrayEtat=array('actif','inactif');
	    $sql="SELECT * FROM `prod`.`bannieres` WHERE set_id='".$id."'";
	    $resSql=$bd->requete($sql);
	    
	    while ($res=mysql_fetch_assoc($resSql))
	    {
		$setValue=array();
		
		if ($res['type']=='image'):
		    
		    if ($level=='hard')
			$link_val=TARGET_LINK_HARD;			
		    else
			$link_val=TARGET_LINK;
		    
		    $setValue[]=' `liens` = CONCAT(\''.$link_val.'\', `nom`) ';
		    
		    $name='ban_exist_';
		    
		else:
		    $name='ban_txt_exist_';
		endif;

		$name2=$name.'actif_';
		$name2.=$res['banniere_id'];

		$name.=$res['banniere_id'];

		$nameTitre='ban_titre_exist_'.$res['banniere_id'];
		$txtBAN='ban_txt_exist_'.$res['banniere_id'];

		if (!empty($_POST[$nameTitre]))
		{
		    $text=$_POST[$nameTitre];
		    $text=$this->preventText($text);
		    $setValue[]=" `text`='".$text."'";
		}
		elseif(!empty($_POST[$txtBAN]))
		{
		    $text=$_POST[$txtBAN];
		    $text=$this->preventText($text);
		    $setValue[]=" `text`='".$text."'";
		}


		if (!empty($_POST[$name2]) && in_array($_POST[$name2],$arrayEtat))
		    $setValue[]=" `etat`='".$_POST[$name2]."'";

		if (!empty($setValue)):
		    $values=implode(',',$setValue);
		    $up="UPDATE `prod`.`bannieres` SET ";
		    $up.=$values;
		    $up.=" WHERE  banniere_id = '".$res['banniere_id']."'";

		    $bd->requete($up);
		endif;
			
		unset($name);unset($name2);unset($etat);unset($text);
	    }
	}
	public function preventText($text){
        if(get_magic_quotes_gpc()) // prevents duplicate backslashes
			$text = stripslashes($text);

		$text = mysql_escape_string(htmlentities($text, ENT_QUOTES));
		return $text;
	}
}
?>
