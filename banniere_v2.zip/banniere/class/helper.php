<?php
/**
 * Pagination
 *
 * @author Nofy
 * 
 */
class Helper{
    
    /**
     * pagination 
     */
    public function paginate($url, $link, $total, $current, $adj=3) 
    {
        // Initialisation des variables
        $prev = $current - 1; 
        $next = $current + 1; 
        $penultimate = $total - 1; 
        $pagination = ''; 

        if ($total > 1) {
            if ($current == 2) {
                $pagination .= "<a href=\"{$url}\"><<</a>";
            } elseif ($current > 2) {
                $pagination .= "<a href=\"{$url}{$link}{$prev}\"><<</a>";
            } else {
                $pagination .= '<span class="inactive"><<</span>';
            }

             /*  CAS 1 : au plus 12 pages -> pas de troncature  */
            if ($total < 7 + ($adj * 2)) {
                $pagination .= ($current == 1) ? '<span class="active">1</span>' : "<a href=\"{$url}\">1</a>"; 

                for ($i=2; $i<=$total; $i++) {
                    if ($i == $current) {
                        $pagination .= "<span class=\"active\">{$i}</span>";
                    } else {
                        $pagination .= "<a href=\"{$url}{$link}{$i}\">{$i}</a>";
                    }
                }
            }
             /*  CAS 2 : au moins 13 pages -> troncature */
            else {
                if ($current < 2 + ($adj * 2)) {
                    $pagination .= ($current == 1) ? "<span class=\"active\">1</span>" : "<a href=\"{$url}\">1</a>";

                    for ($i = 2; $i < 4 + ($adj * 2); $i++) {
                        if ($i == $current) {
                            $pagination .= "<span class=\"active\">{$i}</span>";
                        } else {
                            $pagination .= "<a href=\"{$url}{$link}{$i}\">{$i}</a>";
                        }
                    }

                    // pour marquer la troncature
                    $pagination .= '<span class="troncature">&hellip;</span>';

                    // et enfin les deux derniers numéros
                    $pagination .= "<a href=\"{$url}{$link}{$penultimate}\">{$penultimate}</a>";
                    $pagination .= "<a href=\"{$url}{$link}{$total}\">{$total}</a>";
                }
                elseif ( (($adj * 2) + 1 < $current) && ($current < $total - ($adj * 2)) ) {
                    $pagination .= "<a href=\"{$url}\">1</a>";
                    $pagination .= "<a href=\"{$url}{$link}2\">2</a>";
                    $pagination .= '<span class="troncature">&hellip;</span>';

                    for ($i = $current - $adj; $i <= $current + $adj; $i++) {
                        if ($i == $current) {
                            $pagination .= "<span class=\"active\">{$i}</span>";
                        } else {
                            $pagination .= "<a href=\"{$url}{$link}{$i}\">{$i}</a>";
                        }
                    }

                    $pagination .= '<span class="troncature">&hellip;</span>';

                    // et les deux derniers numéros
                    $pagination .= "<a href=\"{$url}{$link}{$penultimate}\">{$penultimate}</a>";
                    $pagination .= "<a href=\"{$url}{$link}{$total}\">{$total}</a>";
                }
                else {
                    $pagination .= "<a href=\"{$url}\">1</a>";
                    $pagination .= "<a href=\"{$url}{$link}2\">2</a>";
                    $pagination .= '<span class="troncature">&hellip;</span>';

                    // puis des neuf derniers numéros
                    for ($i = $total - (2 + ($adj * 2)); $i <= $total; $i++) {
                        if ($i == $current) {
                            $pagination .= "<span class=\"active\">{$i}</span>";
                        } else {
                            $pagination .= "<a href=\"{$url}{$link}{$i}\">{$i}</a>";
                        }
                    }
                }
            }

             /*  Affichage du bouton [suivant] */
            if ($current == $total)
                $pagination .= "<span class=\"inactive\">>></span>\n";
            else
                $pagination .= "<a href=\"{$url}{$link}{$next}\">>></a>\n";
        }
        else if ($total == 1) {
            $pagination = "<span class=\"active\">1</span>";
        }
        return ($pagination);
    }

    /**
     * Choix Nombre enregistrement à afficher par page
     */
    public function paginateSelect($nb_par_page, $nb_total_resultats){

        $paginationSelect  = '<select onchange="getval(this);" class="nbParPage">';
                $i = 10;
                while ($i <= 100) {
                    $selected = ($i == $nb_par_page) ? " selected" : "";
                    $paginationSelect .= '<option value="' . $i . '"' . $selected . '>' . $i . ' par page</option>';
                    $i += 10;
                }
        $paginationSelect .= '</select>';
        $paginationSelect .= ' sur ' . $nb_total_resultats . ' enregistrements';
    
        return ($paginationSelect);    
    }

}
?>