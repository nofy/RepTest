<?php
	require_once('config.php');
	require_once(LINKTODB);
	require_once('class/set.php');
	require_once('class/banniere.php');
	//require_once('class/niche.php');

if (!empty($_POST['save']) || !empty($_POST['update']) ):
    include('save.php');
endif;


if (empty($_GET['page'])){$page=0;}
else {$page=intval($_GET['page']);}

switch($page)
{
	case 2:
		include('pages/demo_bannerrequest.php');
	break;
	case 1:
		include('pages/creer_set.php');
		break;
	case 0:
	default:
        include('pages/chercher_set.php');

		$bd = new BD();
		$set=new set;
		$listSet=$set->listSet($bd);
                $aff_listecontenus = aff_listecontenus($bd);
                $table_recap=tableau_recap($bd,$aff_listecontenus);
                $txt  ='<link rel="stylesheet" media="screen" href="modules/onglets/banniere/pages/style.css" />';
                $txt .=	'<div style="width:1600px">';
        $txt .= '<div class="myblock"><h2><a href="accueil.php?cur=banniere&amp;page=1" >Cr&eacute;er un nouveau set</a></h2></div>';
        $txt .= '<div class="myblock">'.
                    '<h2><a href="javascript:void(0);" id="chercher_banniere">Rechercher sur les sets existant</a></h2>'.
                    $searchSet.
                '</div>';
        $txt .= '<div class="myblock">'.
                    '<h2>Modifier un set existant</h2>'.
                    $listSet.
                '</div>';
        echo $txt;
                echo '<div id="recapdiv" >'.$table_recap.'</div>';
                $txt .= '</div>';
	break;

}


function securite_bdd($string)
{
	if (isset($string)):
		if(ctype_digit($string))
			$string = intval($string);
		else{
			if(get_magic_quotes_gpc()) // prevents duplicate backslashes
			{
				$string = stripslashes($string);
			}
			$string = mysql_real_escape_string(htmlentities($string, ENT_QUOTES));
		}
		return $string;
	else:
	    return false;
 	endif;
}


function tableau_recap($bd,$aff_listecontenus){
    
    //recap des affectations de set deja faite
    $array2=array();    
    $sql2="SELECT DISTINCT(id_listecontenus),COUNT(set_id) AS total".
        " FROM bannieres_sets_listecontenus".
        " GROUP BY id_listecontenus";
    $res2 = $bd->requete($sql2);
    
    while ($liste2 = mysql_fetch_assoc($res2))
    {
        $array2[$liste2['id_listecontenus']]=$liste2['total'];
    }    
    
    
    
    $table="<table><tr><td>Niche</td><!--<td>age</td>--><td>Nombre de set affect&eacute;</td></tr>";
    foreach($aff_listecontenus as $liste)
    {
		/** Readmine 2274: Evolution Outil Bannières de l'extranet
		 *	@Author: Nofy
		 *	Descrption: Ne laisser dans la colonne "Niche" que les 18ans
		 */
		if ($liste['age']=='18'):

        if (!empty($array2[$liste['id_listecontenus']]))
        $table.='<tr class="tr_niche" desc="'.$liste['id_listecontenus'].'" >';
            else
        $table.='<tr class="tr_niche" desc="'.$liste['id_listecontenus'].'" style="background-color:#FFC4C4">';

        $table.='<td>'.$liste['nom_listecontenusFRE'].' ('.getNomNicheRepli($aff_listecontenus,$liste['code_liste_repli']).')</td>';
              //  '<td>'.$liste['age'].'</td>';  Retirer de ce tableau de niche, la colonne age (Readmine 2274)
        
        if (!empty($array2[$liste['id_listecontenus']]))
            $table.='<td>'.$array2[$liste['id_listecontenus']].'</td>';
        else
            $table.='<td>0</td>';
        $table.='</tr>';

		endif;
    }
    $table.='</table>';
    
    return $table;
}

function aff_listecontenus($bd){
    $sql="SELECT L.*".
        " FROM aff_listecontenus L".
        " WHERE (L.restriction_distributeur IS NULL OR L.restriction_distributeur LIKE '')".
        " AND deprecated!=1".
        " ORDER BY age DESC,nom_listecontenusFRE";
    $res = $bd->requete($sql);
    
    $table=array();
    
    while ($liste = mysql_fetch_assoc($res))
    {
        $table[] = $liste;
    }
    
    return $table;
}

 function getNomNicheRepli($aff_listecontenus, $code_repli) {
     foreach($aff_listecontenus as $liste){
        if ($liste['code_listecontenus'] == $code_repli) {
            return $liste['nom_listecontenusFRE'];
        }
    }
    return "...";
}
?>
<?php if(true || $page ==0): ?>
<link rel="stylesheet" media="screen"  href="<?php echo URL_BASE ?>modules/onglets/banniere/pages/tablesorter/style.css" />
<link rel="stylesheet" type="text/css" href="modules/onglets/banniere/pages/autocomplete/jquery.autocomplete.css" />
<link rel="stylesheet" media="screen" href="modules/onglets/banniere/pages/style.css" />
<script src="<?php  echo URL_BASE ?>modules/onglets/banniere/js/jquery.tablesorter.js" type="text/javascript"></script>
<script src="<?php  echo URL_BASE ?>modules/onglets/banniere/js/jquery.blockUI.js" type="text/javascript"></script>
<script src="<?php  echo URL_BASE ?>modules/onglets/banniere/js/jquery.autocomplete.js" type="text/javascript"></script>


<script type="text/javascript">
    function getval(_sel){
        var nbPerPage = _sel.value;
        var cible = '?cur=banniere&nb=' + nbPerPage;
        document.location.href = cible;
    }

    function toggleRechercheSet(_this){
        $('#bloc_recherche_banniere').toggleClass('force_display');
    }

    function testSubmit(){
        var nom_select     = $("#nom_select option:selected").val(),
            type_select    = $("#type_select option:selected").val(),
            langue_select  = $("#langue_select option:selected").val(),
            niveau_select  = $("#niveau_select option:selected").val(),
            univers_select = $("#univers_select option:selected").val(),
            niche_select   = $("#niche_select option:selected").val(),
            error = "";

        if (nom_select == "" && type_select == "" && langue_select == "" && niveau_select == "" && univers_select == "" && niche_select == "") {
            error = "Vous avez renseign\351 aucun crit\350res !";
        }
        return error;
    }

    //update level
    function ajax_set_level(_this){
        var _url = "<?php echo URL_BASE ?>" + "modules/onglets/banniere/ajax_banniere.php";
        var _level = $(_this).val();
        var _set_id = $(_this).attr("desc");
        
		$.blockUI({ css: {border: 'none', padding: '15px', backgroundColor: '#000',  'border-radius': '10px', '-webkit-border-radius': '10px', '-moz-border-radius': '10px', opacity: .5, color: '#fff' } });

        //ajax
        $.ajax({
            url:_url,
            type: "POST",
            data: "action=update_level&set_id="+_set_id+"&level="+_level,
            success: function(data){
                changeP(_this);
                $(".set_langue").trigger("update"); 
				if(data!='TRUE'){
					var _imgBan = "<img width='120' style='max-height:100px'  title='' alt='' src='" + data + "'>"; 
					$("td#imgBan_"+_set_id).html(_imgBan);					
				}
				$.unblockUI({ 
					onUnblock: function(){ alert('Le niveau a \351t\351 modifi\351'); } 
				}); 
			}
        });
    }
    
    //update univers
    function ajax_set_univers(_this){
        var _url = "<?php echo $path_url_rep ?>" + "/modules/onglets/banniere/ajax_banniere.php";
        var _univers = $(_this).val();
        var _set_id = $(_this).attr("desc");
        
        //ajax
        $.ajax({
            url:_url,
            type: "POST",
            data: "action=update_univers&set_id="+_set_id+"&univers="+_univers,
            success: function(){
                changeP(_this);
                alert("L'univers a \351t\351 modifi\351");
                $(".set_langue").trigger("update"); 
            }
        });
    }
    
    //update niche
    function ajax_set_niche(_this){
        var _url = "<?php echo URL_BASE ?>" + "modules/onglets/banniere/ajax_banniere.php";
        var _niche = $(_this).val();
        var _set_id = $(_this).attr("desc");
        
        //ajax
        $.ajax({
            url:_url,
            type: "POST",
            data: "action=update_niche&set_id="+_set_id+"&niche="+_niche,
            success: function(){
                changeP(_this);
                alert("La niche a \351t\351 modifi\351");
                $(".set_langue").trigger("update"); 
            }
        });
    }
    
    //update langue
    function ajax_set_langue(_this){
        var _url = "<?php echo URL_BASE ?>" + "modules/onglets/banniere/ajax_banniere.php";;
        var _langue = $(_this).val();
        var _set_id = $(_this).attr("desc");
        var _ln_name = "ZToutes les langues";
        var _value = $(_this).val();
        var _alt = $(_this).attr('alt');
        
        //ajax
        $.ajax({
            url:_url,
            type: "POST",
            data: "action=update_langue&set_id="+_set_id+"&langue="+_langue,
            success: function(){
                array_langue = _alt.split(';');
                 for(var i in ln=array_langue){ 
                    t_ln_name_value = ln[i].split('=');
                    if(t_ln_name_value[0] == _value){
                        _ln_name = t_ln_name_value[1];
                        break;
                    }
                }
               
                $($(_this).parent()).children("p").html(_ln_name);
                alert("La langue a \351t\351 modifi\351");
                $(".set_langue").trigger("update"); 
            }
        });
    }
    
    function changeP(_this){
        _value = $(_this).val();
        $($(_this).parent()).children("p").html(_value);
    }
    
    $('document').ready(function(){

        $("#chercher_banniere").click(function(){
           toggleRechercheSet(this);
        });

        $(".search_set").on('click',(function() {
            var error = testSubmit();
            if(error != "") {
                alert(error);
                return false;
            } else {
                document.form_search_set.submit();
            }
        }));


        $('#nom_text').on('blur', function(){
            if ($.trim($(this).val()) == "") {
                $("#nom_select").val("");
            }
        });
        $('#langue_text').on('blur', function(){
            if ($.trim($(this).val()) == "") {
                $("#langue_select").val("");
            }
        });
        $('#niche_text').on('blur', function(){
            if ($.trim($(this).val()) == "") {
                $("#niche_select").val("");
            }
        });

        /*   Autocompletion for nom set */
        $( "#nom_select" ).change(function() {
            var nom_selected = $.trim($('#nom_select option:selected').text());
            $("#nom_text").val(nom_selected);
        });
        $("#nom_text").autocomplete( nom_src,{ 
            width:298,
            mustMatch: true,
            matchContains: true,
            scroll:true,
            formatItem: function(row, i, max) {
                return row.name ;
            },
            formatMatch: function(row, i, max) {
                return row.name;
            },
            formatResult: function(row) {
                return row.name;
            } 
        });
        $("#nom_text").result(function(event, data, formatted){
            if (data != "" && typeof data != "undefined"){
                $("#nom_select").val(data.code);
            }
        });

        /*   Autocompletion for langue set */
        $( "#langue_select" ).change(function() {
            var langue_selected = $.trim($('#langue_select option:selected').text());
            $("#langue_text").val(langue_selected);
        });
        $("#langue_text").autocomplete( langue_src,{ 
            width:298,
            mustMatch: true,
            matchContains: true,
            scroll:true,
            formatItem: function(row, i, max) {
                return row.name ;
            },
            formatMatch: function(row, i, max) {
                return row.name;
            },
            formatResult: function(row) {
                return row.name;
            } 
        });
        $("#langue_text").result(function(event, data, formatted){
            if (data != "" && typeof data != "undefined"){
                $("#langue_select").val(data.code);
            }
        });

        /*   Autocompletion for niche set */
        $( "#niche_select" ).change(function() {
            var niche_selected = $.trim($('#niche_select option:selected').text());
            $("#niche_text").val(niche_selected);
        });
        $("#niche_text").autocomplete( niche_src,{ 
            width:298,
            mustMatch: true,
            matchContains: true,
            scroll:true,
            formatItem: function(row, i, max) {
                return row.name ;
            },
            formatMatch: function(row, i, max) {
                return row.name;
            },
            formatResult: function(row) {
                return row.name;
            } 
        });
        $("#niche_text").result(function(event, data, formatted){
            if (data != "" && typeof data != "undefined"){
                $("#niche_select").val(data.code);
            }
        });

        // bind level
        $(".set_level").change(function(){
           ajax_set_level(this);
        });
        
        //bind univers
        $(".set_univers").change(function(){
           ajax_set_univers(this);
        });
        
        //bind niche
        $(".set_niche").change(function(){
           ajax_set_niche(this);
        });
        
        //bind langue
        $(".set_langue").change(function(){
           ajax_set_langue(this);
        });
        
        //surligner tous les sets associés à la niche 
        //quand on sélectionne une niche dans le tableau
        $(".tr_niche").click(function(){
            _niche_id = $(this).attr("desc");
            $(this).toggleClass("niche_active_select");
            $("#table_set  tr").each(function(){
                if($(this).attr("desc")== _niche_id){
                    $(this).toggleClass("set_active_select");
                }
            });
        });
        
        //initialisation table sorter
        $("#table_set").tablesorter({
            headers: { 6: { sorter: false}}
        });
    });
</script>
<?php endif; ?>