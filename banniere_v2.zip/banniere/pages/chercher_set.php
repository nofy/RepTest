<?php
/**
 * @Author Nofy
 * Formulaire de recherche banniere
 */
$bd = new BD();
if (empty($set)) {
     $set = new set;
}

$_nomAllSets      = $set->getFieldAllSets("nom",  $bd);
$_typeAllSets     = $set->getFieldAllSets("type", $bd);
$_universAllSets  = $set->getFieldAllSets("univers");
$_niveauAllSets   = $set->getFieldAllSets("niveau");
$_langueAllSets   = $set->getFieldAllSets("langue", $bd);
$_nicheAllSets    = $set->getFieldAllSets("niche", $bd);

/* initialisation */
$type_selected    = "";
$univers_selected = "";
$niveau_selected  = "";
$nom_selected     = "";
$langue_selected  = "";
$niche_selected   = "";
$force_display    = "";
$flag_search      = false;
$flag_search_name = false;

if (isset($_REQUEST['type']) && $_REQUEST['type'] == "search"){
    $force_display = " force_display";
    if (!empty($_POST['nom_select'])) {
        $flag_search_name = true;
    }
    $flag_search = true;
}

ob_start();
?>
<div id="bloc_recherche_banniere" class="bloc_recherche_banniere<?php echo $force_display ?>" style="display:none;">
<form id="form_search_set" name="form_search_set"  method="POST" action="accueil.php?cur=banniere" >
    <input type="hidden" name="type" value="search" />
    <!-- Recherche par type -->
    <div class="search_content">
        <label for="type_select" class="description">Type :</label>
        <div class="bloc_autocomplete">
            <select id="type_select" name="type_select"> 
                <option></option>
                <?php foreach ($_typeAllSets as $opt) :
                           if ($flag_search && $flag_search_name == false && !empty($_POST['type_select'])):
                               $type_selected = $opt->type == $_POST['type_select'] ? 'selected="selected"' : ''; 
                           endif;
                ?>
                <option value="<?php echo $opt->type ?>"<?php echo $type_selected ?>><?php echo trim($opt->type) ?></option>
                <?php endforeach ?>
            </select>
        </div>
    </div>
    <!-- Recherche par Nom -->
    <div class="search_content">
        <label for="nom_text" class="description">Nom :</label>
        <div class="bloc_autocomplete">
            <select class="element autocomplete" id="nom_select" name="nom_select"> 
                <option></option>
                <?php foreach ($_nomAllSets as $opt) :
                           if ($flag_search && $flag_search_name && !empty($_POST['nom_select'])):
                               $nom_selected = $opt->set_id == $_POST['nom_select'] ? 'selected="selected"' : ''; 
                           endif;
                ?>
                <option value="<?php echo $opt->set_id ?>"<?php echo $nom_selected ?>><?php echo trim($opt->reference) ?></option>
                <?php endforeach ?>
            </select>
            <input type="text" name="nom_text" id="nom_text" autocomplete="off" value="<?php if ($flag_search && $flag_search_name && !empty($_POST['nom_select'])) echo $_POST['nom_text'] ?>"/>
        </div>
    </div>
    <!-- Recherche par univers -->
    <div class="search_content">
        <label for="univers_select" class="description">Univers :</label>
        <div class="bloc_autocomplete">
            <select id="univers_select" name="univers_select"> 
                <option></option>
                <?php foreach ($_universAllSets as $value) :
                           if ($flag_search && $flag_search_name == false && !empty($_POST['univers_select'])): 
                               $univers_selected = $value == $_POST['univers_select'] ? 'selected="selected"' : ''; 
                           endif;
                ?>
                <option value="<?php echo $value ?>"<?php echo $univers_selected ?>><?php echo trim($value) ?></option>
                <?php endforeach ?>
            </select>
        </div>
    </div>
    <!-- Recherche par langue -->
    <div class="search_content">
        <label for="langue_text" class="description">Langue :</label>
        <div class="bloc_autocomplete">
            <select id="langue_select" name="langue_select"> 
                <option></option>
                <?php foreach ($_langueAllSets as $k => $arrayValues):
                           if ($flag_search && $flag_search_name == false && !empty($_POST['langue_select'])):
                               $langue_selected = trim($arrayValues['langue_iso2']) == $_POST['langue_select'] ? 'selected="selected"' : ''; 
                           endif;
                ?>
                <option value="<?php echo trim($arrayValues['langue_iso2']) ?>"<?php echo $langue_selected ?>><?php echo trim($arrayValues['nom']) ?></option>
                <?php endforeach ?>
            </select>
            <input type="text" name="langue_text" id="langue_text" autocomplete="off" value="<?php if ($flag_search && $flag_search_name == false && !empty($_POST['langue_select'])) echo $set->getLangueSelectSearch($bd, trim($_POST['langue_select'])); ?>"/>
        </div>
    </div>
    <!-- Recherche par niveau -->
    <div class="search_content">
        <label for="niveau_select" class="description">Niveau :</label>
        <div class="bloc_autocomplete">
            <select id="niveau_select" name="niveau_select"> 
                <option></option>
                <?php foreach ($_niveauAllSets as $value) :
                           if ($flag_search && $flag_search_name == false && !empty($_POST['niveau_select'])):
                               $niveau_selected = $value == $_POST['niveau_select'] ? 'selected="selected"' : ''; 
                           endif;
                ?>
                <option value="<?php echo $value ?>"<?php echo $niveau_selected ?>><?php echo trim($value) ?></option>
                <?php endforeach ?>
            </select>
        </div>
    </div>
    <!-- Recherche par Niche -->
    <div class="search_content">
        <label for="niche_text" class="description">Niche :</label>
        <div class="bloc_autocomplete">
            <select id="niche_select" name="niche_select"> 
                <option></option>
                <?php foreach ($_nicheAllSets as $k => $arrayValues):
                           if ($flag_search && $flag_search_name == false && !empty($_POST['niche_select'])):
                               $niche_selected = trim($arrayValues['id_listecontenus']) == $_POST['niche_select'] ? 'selected="selected"' : ''; 
                           endif;
                ?>
                <option value="<?php echo trim($arrayValues['id_listecontenus']) ?>"<?php echo $niche_selected ?>><?php echo trim($arrayValues['nom_listecontenusFRE']) ?> (<?php echo getNomNicheRepli($_nicheAllSets,$arrayValues['code_liste_repli']); ?>)</option>
                <?php endforeach ?>
            </select>
            <input type="text" name="niche_text" id="niche_text" autocomplete="off" value="<?php if ($flag_search && $flag_search_name == false && !empty($_POST['niche_select'])) echo $set->getNicheSelectSearch($bd, trim($_POST['niche_select'])); ?>"/>
        </div>
    </div>
    <div class="bloc_submit">
        <input type="submit" name="submit" value="Chercher" class="search_set" />
    </div>
</form>
</div>
<?php
$searchSet = ob_get_contents();
ob_end_clean();
?>
<script type="text/javascript">
    nom_src = [
        <?php foreach ($_nomAllSets as $opt): ?>
                {code:"<?php echo $opt->set_id ?>", name:"<?php echo trim($opt->reference) ?>"},
        <?php endforeach ?>
    ];

    langue_src = [
        <?php foreach ($_langueAllSets as $k => $arrayValues): ?>
                {code:"<?php echo trim($arrayValues['langue_iso2']) ?>", name:"<?php echo trim($arrayValues['nom']) ?>"},
        <?php endforeach ?>
    ];

    niche_src = [
        <?php foreach ($_nicheAllSets as $k => $arrayValues): ?>
                {code:"<?php echo trim($arrayValues['id_listecontenus']) ?>", name:"<?php echo trim($arrayValues['nom_listecontenusFRE']) .' ('.getNomNicheRepli($_nicheAllSets,$arrayValues['code_liste_repli']).')'; ?>"},
        <?php endforeach ?>
    ];

</script>