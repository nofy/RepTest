<?php

$bd = new BD();

if (empty($set))
{$set=new set;}


if (!empty($_GET['set']))
{
	$id=intval($_GET['set']);
	$set->init($bd,$id);

	if (!empty($set->listBan)){
		$arrayImg=array();
		while($BI=mysql_fetch_assoc($set->listBan)):
			$ban=new banniere;
			$ban->getBanImg($BI);
        	$arrayBan[]=$ban;
			unset($ban);
        endwhile;
	}
	if (!empty($set->listBanTxt)){
		$arrayTxt=array();
		while($BT=mysql_fetch_assoc($set->listBanTxt)):
			$ban=new banniere;
			$ban->getBanTxt($BT);
        	$arrayTxt[]=$ban;
			unset($ban);
        endwhile;
	}
}
$listCamp=listCampagne('FRE');
$listPays=listPays();
$listLangue=listLangue();

/** affichage du bon select pour les niches **/

$nicheHetero=getNiche('hetero');//default hetero
$nicheGay=getNiche('gay');
$nicheMixte=getNiche('mixte');

if(empty($set->type) || $set->type!='vod'){
    $cssNicheHetero=$cssNicheGay=$cssNicheMixte='display:none';
}else if(empty($set->univers) || (!empty($set->univers) && $set->univers=='mixte')) {
    $cssNicheHetero=$cssNicheGay='display:none';
    $cssNicheMixte='display:block';
}else if(!empty($set->univers) && $set->univers=='hetero') {
    $cssNicheGay=$cssNicheMixte='display:none';
    $cssNicheHetero='display:block';
}else if(!empty($set->univers) && $set->univers=='gay') {
    $cssNicheHetero=$cssNicheMixte='display:none';
    $cssNicheGay='display:block';
}
/** affichage du bon select pour les niches **/

if (!empty($_COOKIE['author']))
    $author=$_COOKIE['author'];
else
    $author="";

?>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="modules/onglets/banniere/js/date.js" type="text/javascript"></script>
<script src="modules/onglets/banniere/js/jquery.datePicker.js" type="text/javascript"></script>
<script src="modules/onglets/banniere/js/ban.js" type="text/javascript"></script>
<link rel="stylesheet" media="screen" href="modules/onglets/banniere/pages/style.css" />
<link rel="stylesheet" media="screen" href="modules/onglets/banniere/pages/datePicker.css" />
<script type="text/javascript" charset="utf-8">
$(function()
{
    Date.format = 'yyyy-mm-dd';
	$('.date-pick').datePicker({autoFocusNextInput: true});//.val(new Date().asString()).trigger('change');
});
</script>
<div style="margin:20px auto">
	<a href="accueil.php?cur=banniere">Retour</a>
</div>

<form action="accueil.php?cur=banniere&page=0" id="creer_set" onSubmit="return controlSubmit()" name="creer_set" method="post" enctype="multipart/form-data">
	<input type="hidden" name="save" value="set" />
	<input type="hidden" name="my_set_id" value="<?php echo $set->id ?>" id="my_set_id" />
	<ul class="banner_ever">
		<li>
		    <div class="entete"> _1_ Information globale du nouveau set</div>
	      	<table>
				<tr>
					<td><label for="set_ref">R&eacute;f&eacute;rence du Set : </label></td>
					<td style="text-align:right"><input id="set_ref" name="set_ref" value="<?php echo $set->ref; ?>" id="set_ref"/></td>
				</tr>
				<tr>
					<td colspan="2" style="text-align:left">Utiliser ce set par d&eacute;faut pour Banner Request <input style="float:right" type="checkbox" name="set_default" value="yes" <?php if ($set->default=='1') echo 'checked="checked"'; ?>/></td>
				</tr>
				<tr>
					<td>
						<label for="set_etat">Etat du Set</label>
					</td>
					<td style="text-align:right">
						<select name="set_etat" id="set_ref_actif">
							<option value="actif" <?php if ($set->etat=="actif") echo 'selected="selected"'; ?> >actif</option>
							<option value="inactif" <?php if ($set->etat=="inactif") echo 'selected="selected"'; ?> >inactif</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<label for="set_level">Niveau du Set</label>
					</td>
					<td style="text-align:right">
						<select name="set_level" id="set_level">
							<option value="" <?php if (empty($set->level)) echo 'selected="selected"'; ?> ></option>
							<option value="generaliste" <?php if ($set->level=="generaliste") echo 'selected="selected"'; ?> >generaliste</option>
							<option value="soft" <?php if ($set->level=="soft") echo 'selected="selected"'; ?> >soft</option>
							<option class="preset" value="hard" <?php if ($set->level=="hard") echo 'selected="selected"'; ?> >hard</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<label for="set_univers">Univers du Set</label>
					</td>
					<td style="text-align:right">
						<select name="set_univers" id="set_univers">
							<option value="" <?php if (empty($set->univers)) echo 'selected="selected"'; ?> ></option>
							<option class="preset" value="hetero" <?php if ($set->univers=="hetero") echo 'selected="selected"'; ?> >hetero</option>
							<option value="gay" <?php if ($set->univers=="gay") echo 'selected="selected"'; ?> >gay</option>
							<option value="mixte" <?php if ($set->univers=="mixte") echo 'selected="selected"'; ?> >mixte</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<label for="set_type">Type du Set</label>
					</td>
					<td style="text-align:right">
						<select name="set_type" id="set_type">
							<option value="" <?php if (empty($set->type)) echo 'selected="selected"'; ?> ></option>
							<option class="preset" value="vod" <?php if ($set->type=="vod") echo 'selected="selected"'; ?> >VOD</option>
							<option value="game" <?php if ($set->type=="game") echo 'selected="selected"'; ?> >Jeux</option>
							<option value="form" <?php if ($set->type=="form") echo 'selected="selected"'; ?> >Formulaire</option>
							<option value="app" <?php if ($set->type=="app") echo 'selected="selected"'; ?> >Application</option>
							<option value="dating" <?php if ($set->type=="dating") echo 'selected="selected"'; ?> >Chat</option>
						</select>
					</td>
				</tr>
                                <tr>
					<td>
                                            <label for="set_type_hetero" id="label_n_hetero" class="for_niche" style="<?php echo $cssNicheHetero;?>" >Niches H&eacute;t&eacute;ro</label>
                                            <label for="set_type_gay" id="label_n_gay" class="for_niche" style="<?php echo $cssNicheGay;?>">Niches Gay</label>
                                            <label for="set_type_mixte" id="label_n_mixte" class="for_niche" style="<?php echo $cssNicheMixte;?>">Toutes les niches</label>
					</td>
					<td style="text-align:right">
                                            <select name="set_niche_hetero" id="set_niche_hetero" class="for_niche" style="<?php echo $cssNicheHetero;?>">
                                                <?php displaySelect($nicheHetero,$set->niche); ?>
                                            </select>
                                            <select name="set_niche_gay" id="set_niche_gay" class="for_niche" style="<?php echo $cssNicheGay;?>">
                                                <?php displaySelect($nicheGay,$set->niche); ?>    
                                            </select>
                                            <select name="set_niche_mixte" id="set_niche_mixte" class="for_niche" style="<?php echo $cssNicheMixte;?>">
                                                <?php displaySelect($nicheMixte,$set->niche); ?>    
                                            </select>
                                            <input type="hidden" value="" name="niche" id="niche"/>
					</td>
				</tr>
			</table>
		</li>
		<li>
		    <div class="entete"> _2_ S&eacute;lection des dates de validit&eacute; du set</div>
			<table>
				<tr>
					<td>
						<input name="date1" id="date1" class="date-pick"  value="<?php  echo substr($set->datedebut,0,10) ?>"/>
						<label for="date1" style="margin-left:10px">Date d&eacute;but de pr&eacute;sentation du set</label>
					</td>
				</tr>
				<tr>
				    <td>
				    <div id="bloc_date2" <?php if (!empty($set->nodatelimit)){ echo 'style="display:none;"';} ?> >
						<input name="date2" id="date2" class="date-pick"  value="<?php  echo substr($set->datefin,0,10); ?>"/>
						<label for="date2" style="margin-left:10px">Date de fin de pr&eacute;sentation du set</label>
					</div>
					<br /><br />
					<div style="float:left;" >
						<input style="float:left;" type="checkbox" id="no_date_limit" value="date2_no_limit" <?php if (!empty($set->nodatelimit)){ echo 'checked="checked"';}?> />Pas de limite dans le temps</div>
					</td>
				</tr>
			</table>
		</li>
		<li style="width:200px">
        		<div class="entete">_3_ Liste des pays associ&eacute;s au set</div>
        	<div id="pays_box">
				<?php
				echo '<input type="checkbox" name="set_tous_pays" value="1" id="set_tous_pays"';
					if (!empty($set->TSPays))
					    echo ' checked="checked" ';
				echo ' /> Tous les pays <br class="clr"/>';

				while($pays=mysql_fetch_assoc($listPays)):
				    echo '<input type="checkbox" name="set_pays[]" value="'.$pays['code'].'" class="set_pays"';
					if (in_array($pays['code'],$set->listPays) || !empty($set->TSPays))
					    echo ' checked="checked" ';
					echo ' /><span>'.$pays['nom'].'</span><br class="clr"/>';
				endwhile;
				?>
			</div>
		</li>
		<li>
        	<div class="entete">_4_ La langue associ&eacute; au set</div>
        	<div id="langue_box">
				<table  width="100%">
				<tr>
					<td>Toutes les langues</td>
					<td><?php echo '<input type="checkbox" name="set_tous_langues" value="1" id="set_tous_langue"';
					if (!empty($set->TSLangue))
					    echo ' checked="checked" ';
					echo ' />'; ?></td>
				</tr>
				<?php
				while($langue=mysql_fetch_assoc($listLangue)):
        			echo '<tr>';
						echo '<td><span class="spanlang">'.$langue['nom'].'</span></td>';
						echo '<td ><input type="checkbox" name="set_langues[]" value="'.$langue['langue_iso2'].'-'.$langue['langue_iso3'].'-'.$langue['langue_wister'].'"';
						if ((!empty($set->langue) && $set->langue==$langue['langue_iso2']) || !empty($set->TSLangue))
							{echo 'checked="checked"';}
						echo ' class="set_langue langue_'.$langue['langue_iso3'].'" /></td>';
					echo '</tr>';
				endwhile;
				?>
				</table>
			</div>
		</li>
		<li>
        	<div class="entete">_5_ Liste des campagnes associ&eacute;es au set</div>
        	<div id="campagne_box">
        		<table width="100%">
        		<tr><td>Id</td><td>Nom</td><td>&Eacute;tat</td><td>Conf</td><td>&nbsp;</td></tr>
				<?php
					while($camp=mysql_fetch_assoc($listCamp)):
					    echo '<tr><td>'.$camp['idoffer'];
							if (!empty($camp['adult']) ){echo ' <span style="font-size:8px">(adulte)</span>';}
						echo '</td><td>'.$camp['name'].'</td><td>'.$camp['state'].'</td><td>'.$camp['conf'].'</td>';
						echo '<td><input type="checkbox" name="set_campagnes[]" class="set_camp camp_'.$camp['idoffer'].'" value="'.$camp['idoffer'].'" ';
						if (in_array($camp['idoffer'],$set->listCamp))
					    	echo ' checked="checked" ';
						echo ' /></td></tr>';
					endwhile;
				?>
				</table>
			</div>
		</li>
		<li style="width:200px">
		    <!--<div class="entete">_6_ Liste des th&egrave;mes du set</div>
		    <div id="theme_box">
				<?php
				/*while($theme=mysql_fetch_assoc($listTheme)):
				    echo '<input type="checkbox" name="set_themes[]" value="'.$theme['id'].'"';
                    if (in_array($theme['id'],$set->listTheme))
					    echo ' checked="checked" ';
					echo ' class="set_theme" /><span>'.$theme['nom'].'</span>';
					if (!empty($theme['adult'])){echo ' <span style="font-size:8px">(adulte)</span>';}
					echo '<br class="clr"/>';
				endwhile;*/
				?>
			</div>-->
		</li>
		<li style="width:90%">
			<div id="images">
				<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo MAX_SIZE; ?>" />
				<div class="entete">_7_ Gestion des banni&egrave;res images du set</div>
				<label for="ban">Fichier (tous formats | max. 1 Mo) :</label><br />
				<table id="tableban">
					<tr>
						<td>Bani&egrave;res</td>
						<td>Banni&egrave;re Active</td>
					</tr>
					<tr>
                                            <td><input type="file" name="ban[]" class="ban" multiple /></td>
						<td>
							<select name="ban_actif[]">
								<option value="actif"  selected="selected" >actif</option>
								<option value="inactif" >inactif</option>
							</select>
						</td>
					</tr>
				</table>
				<div id="addimage"> Ajouter une autre banni&egrave;re image</div>
				<?php
				if(!empty($arrayBan)):
					echo '<table width="auto"><tr height="60"><td height="60">Banni&egrave;res</td><td height="60"><div class="T60">size</div><div class="T60">&eacute;tat</div><div class="T60">suppr</div></td></tr>';
					for($i=0;$i<count($arrayBan);$i++)
					{
					    echo '<tr>';
						echo '<th><img src="'.$arrayBan[$i]->liens.'" width="'.$arrayBan[$i]->width.'" '.
							 ' height="'.$arrayBan[$i]->height.'" alt="'.$arrayBan[$i]->text.'" '.
							 ' title="'.$arrayBan[$i]->text.'" style="float:left"/>';
						echo '</th>';
						echo '<td  style="vertical-align:center;" height="60px">';
						echo 	'<div class="T60">';
					    echo 		$arrayBan[$i]->size;
					    echo 	'</div>';
						echo 	'<div class="T60">';
						echo 		'<select name="ban_exist_actif_'.$arrayBan[$i]->ban_id.'">';
						if ($arrayBan[$i]->etat=='actif'):
							echo		'<option value="actif" selected="selected" >actif</option>'.
										'<option value="inactif" >inactif</option>';
						else:
						    echo		'<option value="actif" >actif</option>'.
										'<option value="inactif" selected="selected" >inactif</option>';
						endif;
						echo 		'</select>';
						echo 	'</div>';
						echo 	'<div class="T60">';
						echo 		'<input type="checkbox" name="delete_ban[]" value="'.$arrayBan[$i]->ban_id.'" class="delete_ban" />';
						echo 	'</div>';
						echo '</td></tr>';
					 }
				endif;
				?>
				</table>
			</div>
		</li>
		<li>
			<div id="ban_txt">
				<div class="entete">_8_ Gestion des banni&egrave;res textes</div>
				<label for="ban">&nbsp;</label><br />
				<table id="tabletxt">
					<tr>
						<td>Banni&egrave;res textes</td>
						<td>Banni&egrave;re Active</td>
						<td>suppr</td>
					</tr>
	                <?php
						if(!empty($arrayTxt)):
							for($i=0;$i<count($arrayTxt);$i++)
							{
							 ?>
							 <tr>
								<td><textarea rows="4" cols="40" name="ban_txt_exist_<?php echo $arrayTxt[$i]->ban_id ?>" class="ban_txt_exist"><?php echo $arrayTxt[$i]->text ?></textarea></td>
								<td>
									<select name="ban_txt_exist_actif_<?php echo $arrayTxt[$i]->ban_id ?>">
										<option value="actif" <?php if ($arrayTxt[$i]->etat=="actif"){echo' selected="selected" ';} ?> >actif</option>
										<option value="inactif" <?php if ($arrayTxt[$i]->etat!="actif"){echo' selected="selected" ';} ?> >inactif</option>
									</select>
								</td>
								<td>
									<input type="checkbox" name="delete_ban_txt[]" value="<?php echo $arrayTxt[$i]->ban_id;?>" class="delete_ban_txt" />
								</td>
							</tr>
							 <?php
							}
						endif;
					?>
					<tr>
						<td><textarea rows="4" cols="40" name="ban_txt[]" class="ban_txt"></textarea></td>
						<td>
							<select name="ban_actif_txt[]">
								<option value="actif"  selected="selected" >actif</option>
								<option value="inactif" >inactif</option>
							</select>
						</td>
					</tr>
				</table>
				<div id="addtxt"> Ajouter une autre banni&egrave;re texte</div>
			</div>
		</li>
	</ul>
	<br class="clr"/>
        <div>Veuillez indiquer votre nom : <input name="author" tye="text" value="<?php echo $author; ?>" id="author"/></div>
	<br class="clr"/>
	<div>
		<div class="entete">R&eacute;cap</div>
		<table border="1" id="recap">
			<tr>
				<td rowspan="3">R&eacute;f&eacute;rence : </td>
				<td><div id="recap_ref">&nbsp;</div></td>
			</tr>
			<tr>
				<td><div id="recap_ref_actif">&nbsp;</div></td>
			</tr>
			<tr>
				<td>Dates : </td>
				<td><div id="recap_date">&nbsp;</div></td>
			</tr>
			<tr>
				<td>Pays :  </td>
				<td><div id="recap_pays">&nbsp;</div></td>
			</tr>
			<tr>
				<td>Langues : </td>
				<td><div id="recap_lang">&nbsp;</div></td>
			</tr>
			<tr>
				<td>Campagne : </td>
				<td><div id="recap_camp">&nbsp;</div></td>
			</tr>
			<tr>
				<td>Theme : </td>
				<td><div id="recap_theme">&nbsp;</div></td>
			</tr>
			<tr>
				<td rowspan="2">Banni&egrave;res images : </td>
				<td><div id="recap_banImg">&nbsp;</div></td>
			</tr>
			<tr>
				<td><div id="recap_supprbanImg">&nbsp;</div></td>
			</tr>
			<tr>
				<td rowspan="2">Banni&egrave;res textes : </td>
				<td><div id="recap_banTxt">&nbsp;</div></td>
			</tr>
			<tr>
				<td><div id="recap_supprbanTxt">&nbsp;</div></td>
			</tr>
		</table>
	</div>
	<div>
		<div id="error">&nbsp;</div>
	</div>
	<textarea rows="4" cols="40" name="resume" style="display:none" id="resume"></textarea>
	<div style="margin:20px auto">
		<input type="submit" value="valider le set" id="valider_set"/>
	</div>
</form>

<?php
$bd->close();


function listCampagne($lang='FRE', $listC=array())
{
	global $bd;

	$listLang=array('FRE'=>1,'ENG'=>1,'SPA'=>1);
	if (!empty($listLang[$lang]))
	    $lang='FRE';

	$sql="SELECT L.idoffer,L.name,C.conf,C.state,C.adult  FROM `prod`.`aff_campagne_lang` AS L,`prod`.`aff_campagne` AS C".
		 " WHERE L.idoffer=C.id AND lang='".$lang."' ORDER BY name ";

	$in=mywhere($listC);
	if (!empty($in)) {$sql.=' AND idoffer '.$in;}

	$res = $bd->requete($sql);
	if (!empty($res))
		return $res;
	else
	    return false;
}

function listPays($listP=array())
{
	global $bd;

	$sql="SELECT code,nom FROM `prod`.`pays` ";

	$in=mywhere($listP);
	if (!empty($in)){$sql.=' WHERE code '.$in;}

	$res = $bd->requete($sql);

	if (!empty($res))
		return $res;
	else
	    return false;
}

function listLangue($listL=array())
{
	global $bd;

	$sql="SELECT langue_iso2,langue_iso3,langue_wister,nom FROM `prod`.`bannieres_langue` ";

	$in=mywhere($listL);
	if (!empty($in)){$sql.=' WHERE langue_iso2 '.$in;}

	$res = $bd->requete($sql);
	if (!empty($res))
		return $res;
	else
	    return false;
}

function listTheme($lang='FRE', $listT=array())
{
	global $bd;

	$sql="SELECT id,name".$lang." as nom, adult FROM `prod`.`aff_camp_theme` ";

	$in=mywhere($listT);
	if (!empty($in)){$sql.=' WHERE id '.$in;}

	$sql.=" ORDER BY ordre ";

	$res = $bd->requete($sql);
	if (!empty($res))
		return $res;
	else
	    return false;
}
function myWhere($list)
{
	if (!empty($list)):
		$where=implode("','",addslashes($list));
		$where=" IN ('".$where."')";
	else:
		$where="";
	endif;

	return $where;
}
function getNiche($univers = null)
{
    global $bd;
    if ($univers!='gay' && $univers!='hetero' ){$univers='mixte';}

    $ret = array();

    $q = "SELECT L.*,COUNT(BSL.set_id) AS total ".
         " FROM aff_listecontenus AS L LEFT JOIN".
         " bannieres_sets_listecontenus AS BSL ON L.id_listecontenus=BSL.id_listecontenus".
         " WHERE 1".
         " AND (L.restriction_distributeur IS NULL OR L.restriction_distributeur LIKE '')".
         " AND L.age = '18' AND deprecated=0".
         " AND L.univers = '".$univers."'".
         " GROUP BY L.id_listecontenus";

    $res = $bd->requete($q);
    if ($res && mysql_num_rows($res) >= 1)
    {
        while ($row = mysql_fetch_array($res))
        {
            if (!empty($row)){$ret[] = $row;}
        }
    }

    return $ret;
}

function displaySelect($catalog, $idSelected=array())
{
    if (count($catalog) > 0)
    {
        $liste_defaut=explode(',',LISTE_DEFAUT);
        usort($catalog, 'comparer');
        foreach ($catalog as $liste)
        {
            $opt='<option value="'.$liste['id_listecontenus'].'"';
            if (    (!empty($idSelected) && in_array($liste['id_listecontenus'],$idSelected))
                ||  (empty($idSelected) && in_array($liste['id_listecontenus'],$liste_defaut)))
                $opt.='selected="selected" ';
            $opt.='>'.$liste['nom_listecontenusFRE'].' ('.$liste['total'].' set )</option>';
            
            echo $opt;
        }
    }
}
function comparer($a, $b) {return strcmp($a['nom_listecontenusFRE'], $b['nom_listecontenusFRE']);}


/*
 * 
CREATE TABLE IF NOT EXISTS `bannieres_sets_listecontenus` (
  `set_id` int(11) NOT NULL DEFAULT '0',
  `id_listecontenus` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`set_id`,`niche_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
 * 
 * 
 */
?>
