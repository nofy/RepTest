<?php

/*

 * @author     Nico

 */

//configuration pour une connexion via ajax
$hote="localhost";
$environnement = "prod";//bdd
$utilisateur = "root";
$mdp="";

?>
