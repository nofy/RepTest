<?php
switch ($_POST['save'])
{
    case "set":
        $set = new set;
        $bd = new BD();

        if (!empty($_POST['my_set_id']))
            $set->id = intval($_POST['my_set_id']);

        if (!empty($_POST['set_ref'])):
            $ref = securite_bdd($_POST['set_ref']);
            $set->ref = $ref;
        else:
            $set->getRef($bd);
        endif;


        if (!empty($_POST['set_etat'])):
            $etat = securite_bdd($_POST['set_etat']);
            $set->etat = $etat;
        endif;

        if (isset($_POST['set_default']) && 'yes' == $_POST['set_default'])
            $default = securite_bdd('1');
        else
            $default = securite_bdd('0');
        $set->default = $default;

        if (!empty($_POST['set_type'])):
            $type = securite_bdd($_POST['set_type']);
            $set->type = $type;
        endif;
        
        if (!empty($_POST['set_level'])):
            $level = securite_bdd($_POST['set_level']);
            $set->level = $level;
        endif;

        if (!empty($_POST['set_univers'])):
            $univers = securite_bdd($_POST['set_univers']);
            $set->univers = $univers;
        endif;

        if (isset($_POST['date1'])):
            $date1 = securite_bdd($_POST['date1']);
            $set->datedebut = $date1;
        endif;

        if (!empty($_POST['date2']) && empty($_POST['no_date_limit'])):
            $date2 = securite_bdd($_POST['date2']);
            $set->datefin = $date2;
        elseif (!empty($_POST['no_date_limit'])):
            $set->datefin = '0000-00-00 00:00:00';
        endif;

        if (!empty($_POST['set_campagnes'])):
            $arCamp = array();

            foreach ($_POST['set_campagnes'] as $sc)
            {
                $arCamp[] = intval($sc);
            }

            $set->listCamp = $arCamp;
        endif;

        if (!empty($_POST['set_tous_pays'])):
            $set->TSPays = 1;
        elseif (!empty($_POST['set_pays'])):
            $arPays = array();

            foreach ($_POST['set_pays'] as $sp)
            {
                $arPays[] = securite_bdd($sp);
            }

            $set->listPays = $arPays;
        endif;

        if (!empty($_POST['set_tous_langues'])):
            $set->TSLangues = 1;
        elseif (!empty($_POST['set_langues'])):
            $set->langue = securite_bdd($_POST['set_langues'][0]);
        //trigger_error('langue : '.$set->langue);
        endif;

        if (empty($set->type) || $set->type != 'vod'):
            $set->niche = 0;
        elseif ($set->type == 'vod' && !empty($_POST['niche'])):
            $set->niche[0]= intval($_POST['niche']);
        endif;


        if (empty($set->id)):
            if ($set->insertRef($bd)):
                if ($set->insert($bd)):
                    $myResult = 'OK';
                endif;
            endif;
        else:
            if ($set->update($bd)):
                if ($set->insert($bd)):
                    $myResult = 'OK';
                endif;
            endif;
        endif;

        if (!empty($myResult) && $myResult == 'OK'){
            if (!empty($_FILES['ban']['name'][0])){

                if (!empty($_FILES['ban']['name'])){
                    $resImg = array();
                    for ($i = 0; $i < count($_FILES['ban']['name']); $i++)
                    {
                        if (!empty($_FILES['ban']['name'][$i]))
                        {
                            $ban = new banniere;
                            $resImg[] = $ban->saveImg($bd, $set->id, $i,$level);
                            unset($ban);
                        }
                    }
		}
	    }

            if (!empty($_POST['ban_txt'])):

                $listBan = $_POST['ban_txt'];
                $listBanActif = $_POST['ban_actif_txt'];
                for ($i = 0; $i < count($_POST['ban_txt']); $i++)
                {
                    $ban = new banniere;
                    $resImg[] = $ban->saveTxt($bd, $set->id, $listBan[$i], $listBanActif[$i]);
                    unset($ban);
                }
            endif;

            if (!empty($_POST['delete_ban'])):
                $ban = new banniere;
                $banASuppr = $_POST['delete_ban'];
                for ($i = 0; $i < count($_POST['delete_ban']); $i++)
                {
                    $ban->supprBanImg($bd, intval($banASuppr[$i]));
                }
            endif;
            if (!empty($_POST['delete_ban_txt'])):
                $ban = new banniere;
                $banTxtASuppr = $_POST['delete_ban_txt'];
                for ($i = 0; $i < count($_POST['delete_ban_txt']); $i++)
                {
//trigger_error(intval($banTxtASuppr[$i]));
                    $ban->supprBanTxt($bd, intval($banTxtASuppr[$i]));
                }
            endif;
            $ban = new banniere;
            $ban->MAJBan($bd, $set->id,$level);

	}

        $message = 'Action r&eacute;alis&eacute;e par ' . $_POST['author'] . '<br/>';

        if (!empty($_POST['my_set_id']))
		{
			$sujet = 'Banners Extranet Tool - a set has been updated';
            $message.='Modification d\'un set existant : ' . $_POST['set_ref'] . '(id:' . $_POST['my_set_id'] . ')<br />';
		}
        else
		{
			$sujet = 'Banners Extranet Tool - a new set has been created';
            $message.='Cr&eacute;ation d\'un nouveau set : ' . $_POST['set_ref'] . '<br />';
		}

        $message.= '<table>' . $_POST['resume'] . '</table>';
        $destinataire = EMAIL_LIST;
        $headers = "From: \"Extranet\"<extranet@wister.biz>\n";
        $headers .= "Reply-To: extranet@wister.biz\n";
        $headers .= "Content-Type: text/html; charset=\"iso-8859-1\"";
        mail($destinataire, $sujet, $message, $headers);
        /* 			if()
          {trigger_error("L'email a bien été envoyé.");}
          else
          {trigger_error("Une erreur c'est produite lors de l'envois de l'email.");} */



        $bd->close();
	echo '<script language="Javascript">
	window.location.replace("'.HOMEPAGE.'");
	</script>';
        /*   			ob_clean();
          header("Location: ".EXTRANET_ROOT."/accueil.php?cur=banniere&page=0 "); */
        break;
}
?>
