<?php
//require_once();
date_default_timezone_set('Europe/Paris');

$server_name = @$_SERVER['SERVER_NAME'];
switch ($server_name)
{
    case 'www.wister.biz':
    case 'extranet.wister.biz':
    	require_once("/var/www/wister.biz/extranet/env.php");
		define('TARGET_BAN', "/var/www/files.wister.biz/images/affiliation/promotools/bannieres/"); 	// Repertoire cible des bannières
		define('TARGET_LINK',	    'http://t4b.tv/affiliation/promotools/bannieres/');  //base des liens vers les bannières
		define('TARGET_LINK_HARD',  'http://89.185.33.51/partners/affiliation/promotools/bannieres/');
		define('LINKTODB',"/var/www/partners.wister.biz/affiliation/distrib/class.bd.php");
		define('HOMEPAGE', EXTRANET_ROOT."/accueil.php?cur=banniere&page=0");
		define('URL_BASE', EXTRANET_ROOT."/");
		define('AJAX_URL_BASE', EXTRANET_ROOT."/modules/onglets/banniere/index.php");
                define('LISTE_DEFAUT','462,463');
		define('EMAIL_LIST','aymeric.burgaud@wister.fr; yannick.gamiette@wister.fr; sarah.martins@wister.fr; lea.bessaguet@wister.fr');
		break;
	default:
		// require_once("/var/www/int.wister.biz/extranet/env.php");                                                                    // A DECOMMENTER POUR LA MISE EN PROD
        require_once(dirname(__FILE__) . "../../../../env.php");                                                                        // A SUPPRIMER POUR LA MISE EN PROD
		define('TARGET_BAN', "/var/www/int.wister.biz/extranet/modules/onglets/banniere/files/"); 	// Repertoire cible des bannières
		//define('TARGET_LINK', EXTRANET_ROOT."/modules/onglets/banniere/files/");  //base des liens vers les bannières                 // A DECOMMENTER POUR LA MISE EN PROD
		//define('TARGET_LINK_HARD', EXTRANET_ROOT."/modules/onglets/banniere/files/");                                                 // A DECOMMENTER POUR LA MISE EN PROD
        define('TARGET_LINK', 'http://t4b.tv/affiliation/promotools/bannieres/');                                                       // A SUPPRIMER POUR LA MISE EN PROD
		define('TARGET_LINK_HARD', 'http://46.229.173.228/affiliation/promotools/bannieres/');                                          // A SUPPRIMER POUR LA MISE EN PROD
		// define('LINKTODB',"/var/www/int.wister.biz/partners.wister.biz/affiliation/distrib/class.bd.php");                           // A DECOMMENTER POUR LA MISE EN PROD
		define('LINKTODB',dirname(__FILE__)."/class/class.bd.php");                                                                     // A SUPPRIMER POUR LA MISE EN PROD
		define('HOMEPAGE',EXTRANET_ROOT."/accueil.php?cur=banniere&page=0");
		define('URL_BASE', EXTRANET_ROOT."/");
		define('AJAX_URL_BASE', EXTRANET_ROOT."/modules/onglets/banniere/index.php");
                define('LISTE_DEFAUT','462,463');
		define('EMAIL_LIST',"aymeric.burgaud@wister.fr");
		break;
}

define('MAX_SIZE', 1048576);	// Taille max en octets du fichier


?>
