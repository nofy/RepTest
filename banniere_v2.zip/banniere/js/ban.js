function implode (glue, pieces) {
    var i = '',
        retVal = '',
        tGlue = '';
    if (arguments.length === 1) {
        pieces = glue;
        glue = '';
    }
    if (typeof(pieces) === 'object') {
        if (Object.prototype.toString.call(pieces) === '[object Array]') {
            return pieces.join(glue);
        }
        for (i in pieces) {
            retVal += tGlue + pieces[i];
            tGlue = glue;
        }
        return retVal;
    }
    return pieces;
}
$(document).ready(function() {
        
        /*** preset ***/
        if ($('#my_set_id').val()=='0'){
            $('#no_date_limit').click();//pas de limite dans le temps 

            $('#set_tous_pays').click();
            $('.set_pays').attr('checked','checked');//tous les pays 

            $('.langue_eng').attr('checked','checked');//anlais
            
            $('.camp_12').attr('checked','checked');//VOD
            
            $('.preset').attr('selected','selected');//valeur pour le premier bloc info global 
        }
        /*** preset ***/
    
	$('#set_ref').blur(function(){
		var txt=$('#set_ref').val();
		$('#recap_ref').html(txt);
	});
	$('#set_ref_actif').change(function(){
        
		var txt=$('#set_ref_actif').val();
		$('#recap_ref_actif').html(txt);
	});

	$('#set_tous_pays').click(function(){
		if ($(this).attr('checked')=='checked')
		{
			$('.set_pays').attr('checked','checked');
			$('#recap_pays').html('Tous les pays');
		}
		else
		{
			$('.set_pays').removeAttr('checked');
			$('#recap_pays').html('');
		}
	});
	
	$('.set_pays').each(function(){
        $(this).click(function(){
                $('#set_tous_pays').removeAttr('checked');
                $('.set_pays').removeAttr('checked');
                $(this).attr('checked','checked');

			var txtL='';
			txtL=txtL+$(this).parent().parent().children().children().html()+'<br />';

            $('#recap_pays').html(txtL);
		});
	});

	$('#set_tous_langue').click(function(){
		if ($(this).attr('checked')=='checked')
		{
			$('.set_langue').attr('checked','checked');
            $('#recap_lang').html('Valide pour toutes les langues');
		}
		else
		{
			$('.set_langue').removeAttr('checked');
			$('#recap_lang').html('');
		}
	});

	$('.set_langue').each(function(){
        $(this).click(function(){
                $('#set_tous_langue').removeAttr('checked');
                $('.set_langue').removeAttr('checked');
                $(this).attr('checked','checked');

			var txtL='';
			txtL=txtL+$(this).parent().parent().children().children().html()+'<br />';

            $('#recap_lang').html(txtL);
		});
	});

	$('.title_ban').first().change(function(){
		var value=$(this).val();
		$('.title_ban').each(function(){
		    if ($(this).val()==''){$(this).val(value);}
		});
	});

	$('#no_date_limit').click(function(){
		if ($(this).attr('checked')=='checked')
		{
			$('#bloc_date2').css('display','none');
		}
		else
		{$('#bloc_date2').css('display','block');}
	});
	$('ul.banner_ever li').first().next().mouseleave(function(){

		var d1=$('#date1').val();
		if ($('#no_date_limit').attr('checked')=='checked')
		{
			var dtxt='la set est valide du '+d1+' et n\'a pas de date de fin';
		}
		else
		{
		    var d2=$('#date2').val();
            var dtxt='la set commence le '+d1+' et se termine le '+d2;
  		}
  		$('#recap_date').html(dtxt);
	});
	
	$('.set_camp').each(function(){
		$(this).click(function(){
            var txtC='';
			$('.set_camp').each(function(){
                if ($(this).attr('checked')=='checked')
                {
					txtC=txtC+$(this).parent().parent().children().next().html()+'<br />';
				}
			});
			$('#recap_camp').html(txtC);
		});
	});
	
	$('#addimage').click(function(){
		$('#tableban tr:last').after(	'<tr><td><input type="file" name="ban[]" class="ban" /></td>'+
											'<td>'+
												'<select name="ban_actif[]">'+
													'<option value="actif"  selected="selected" >actif</option>'+
													'<option value="inactif" >inactif</option>'+
												'</select>'+
											'</td>'+
										'</tr>');
	});
	$("ul.banner_ever li").last().prev().mouseleave(function() {

		var nbBan=0;
		$("#tableban .ban").each(function(){
			if ($(this).val()!='')
				nbBan=nbBan+1;
		});
		
  		//$('#recap_banImg').html(nbBan+' nouvelle(s) banniere(s) image(s)');
  		
  		if (nbBan==1)
		{
	  		$('#recap_banImg').html(nbBan+' nouvelle banniere image');
		}
		else if(nbBan != 0)
	  		$('#recap_banImg').html(nbBan+' nouvelles bannieres images');
  		
	});

	$('#addtxt').click(function(){
        $('#tabletxt tr:last').after(	'<tr><td><textarea name="ban_txt[]" cols="40" rows="4" class="ban_txt"></textarea></td>'+
											'<td>'+
												'<select name="ban_actif_txt[]">'+
													'<option value="actif"  selected="selected" >actif</option>'+
													'<option value="inactif" >inactif</option>'+
												'</select>'+
											'</td>'+
										'</tr>');
	});
	
	$("ul.banner_ever li").last().mouseleave(function() {

		var nbBanTxt=0;
		$("#tabletxt .ban_txt").each(function(){
			if ($(this).val()!='')
				nbBanTxt=nbBanTxt+1;
		});

		if (nbBanTxt==1)
		{
	  		$('#recap_banTxt').html(nbBanTxt+' nouvelle banniere texte');
		}
		else if(nbBanTxt != 0)
	  		$('#recap_banTxt').html(nbBanTxt+' nouvelles bannieres textes');
	});
	
	$('.delete_ban').click(function(){
	    var i=0;
        $('.delete_ban').each(function(){
			if ($(this).attr('checked')=='checked')
			{
				i=i+1;
			}
		});
		$('#recap_supprbanImg').html(i+' banniere(s) supprimee(s)');
	});
	$('.delete_ban_txt').click(function(){
	    var j=0;
        $('.delete_ban_txt').each(function(){
			if ($(this).attr('checked')=='checked')
			{
				j=j+1;
			}
		});
		$('#recap_supprbanTxt').html(j+' banniere(s)texte(s) supprimee(s)');
	});
        
        /** Partie niche **/
        $('#set_univers,#set_type').change(function(){
            setGoodNiche();
        });
        
        $('.for_niche option').click(function(){
            var val_niche=$(this).attr('value');
            $('#niche').val(val_niche);
        });
        $('.for_niche').change(function(){
            var val_niche=$(this).attr('value');
            $('#niche').val(val_niche);
        });
        if($("#niche").val()==="" && $('#set_type').val()==='vod')
        {
            setGoodNiche();
            $("#niche").val();
        }
        /** Partie niche **/
        
        
});
/***** VERIF FORM *****/
function controlSubmit(){
	var error= new Array();
	var nb=0;
	if ($('#set_type').val()==''){
		error[nb]='il faut selectionner le type';
	}
	if ($('#set_level').val()==''){
		error[nb]='il faut selectionner le niveau';
	}
	if ($('#set_univers').val()==''){
		nb++;
		error[nb]='il faut selectionner l\'univers';
	}
	if ($('#set_ref').val()==''){
		nb++;
		error[nb]='il faut ajouter une reference';
	}
    
	if ($('#author').val()==''){
		nb++;
		error[nb]='vous devez indiquer votre nom';
	}
	
	if ( $('#date1').val()=='' )
	{
		nb++;
		error[nb]='il faut saisir une valeur pour la date de debut';
	}
	if ( $('#date1').val()=='' && $('#no_date_limit').attr('checked')!='checked')
	{
		nb++;
		error[nb]='il faut saisir une valeur pour la date de fin, ou cocher la case pas de limite';
	}
	if ( $('#date1').val()==$('#date2').val() && $('#no_date_limit').attr('checked')!='checked')
	{
        nb++;
		error[nb]='la date de debut et de fin du set sont identiques';
	}

	var mypays='nok';
    if ($('#set_tous_pays').attr('checked')!='checked')
	{
		$('.set_pays').each(function(){
			if ($(this).attr('checked')=='checked')
			{mypays='ok'}
		});
	}

	if ($('#set_tous_pays').attr('checked')!='checked' && mypays!='ok')
	{
        nb=error.length;
		error[nb]='Il faut choisir les pays pour lesquels le set est valide ';
	}

	var mylangue='nok';
	if ($('#set_tous_langue').attr('checked')!='checked')
	{
		$('.set_langue').each(function(){
			if ($(this).attr('checked')=='checked')
			{mylangue='ok';}
		});
	}

	if ($('#set_tous_langue').attr('checked')!='checked' && mylangue!='ok')
	{
        nb=error.length;
		error[nb]='Il faut choisir les langues pour lesquels le set est valide ';
	}

	var mycamp='nok';
	$('.set_camp').each(function(){
		if ($(this).attr('checked')=='checked')
		{mycamp='ok';}
	});

	if (mycamp!='ok')
	{
        nb=error.length;
		error[nb]='Il faut choisir les campagnes pour lesquels le set est valide ';
	}

	if (error.length>0)
	{
	    var str= implode('</li><li>',error);
		var str='<ul><li>'+str+'</li></ul>';

		$('#error').html(str);

		return false;
	}
	else
	{
	    var txt=$('#set_ref').val();
		$('#recap_ref').html(txt);
		var tous=$('#recap').html();
		$('#resume').val(tous);
		
		return true;
	}
	

}



function setGoodNiche(){
    $('.for_niche').css('display','none');
    
    if($('#set_type').val()==='vod' && $('#set_univers').val() !=='mixte')
    {
        var univers=$('#set_univers').val();
        var id_select='#set_niche_'+univers;
        var label_select='#label_n_'+univers;
        $(''+id_select+','+label_select).css('display','');
        
        var idselect=$(''+id_select).val();
        $('#niche').val(idselect);
    }
}